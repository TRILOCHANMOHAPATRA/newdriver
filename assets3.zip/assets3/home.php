<?php
  
session_start();
if(isset($_SESSION['username'])){
   $_SESSION['username'];
}
else{
  header('location:index.php');
}
  
  ?>
  <?php
  
  
 
?>
<?php include_once('layouts/header.php'); 
require('dashboard.php');
?>

<div class="row">

</div>
<?php include_once('layouts/footer.php'); ?>
