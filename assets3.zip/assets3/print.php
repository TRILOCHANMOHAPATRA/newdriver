<?php 
require('includes/dbconfig.php');
$data=new db;
if(isset($_GET['id'])){
    $id=$_GET['id'];   
}
$v=$data-> invoice($id);
$values=$v->fetch(PDO::FETCH_ASSOC);
?>
<script type="text/javascript">     
    function PrintDiv() {    
       var divToPrint = document.getElementById('divToPrint');
       var popupWin = window.open('', '_blank','width=300,height=300');
       popupWin.document.open();
       popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();
            }
 </script>
<div id="divToPrint" style="display:none;">
  <div >
           <?php foreach($values as $value){
    echo $value ."<br>"; 
} ?>      
  </div>
</div>
<div>
  <input type="button" value="print" onclick="PrintDiv();" />
</div>