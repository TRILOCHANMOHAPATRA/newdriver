<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  $table='branch';
  $name=$_POST['name'];
  
  $mobile=$_POST['mobile'];
  $email=$_POST['Email'];
  $address=$_POST['address'];
     $re=$data->insertcostomer($name,$mobile,$email,$address);
      if($re){
       header('location:costomber.php');
      } else {
        header('location:add_branch.php');
      }
   } 
 
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New branch</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_costomber.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Name</label>
                <input type="text" class="form-control" name="name" placeholder="Name">
            </div>
            <div class="form-group">
            <label >mobile number</label>
                <input type="number" class="form-control" name="mobile" placeholder="mobile">
            </div>
            <div class="form-group">
            <label >Email</label>
                <input type="email" class="form-control" name="Email" placeholder="Email">
            </div>
            <div class="form-group">
            <label >address</label>
                <input type="text" class="form-control" name="address" placeholder="address">
            </div>
            
            
            <button type="submit" name="add_cat" class="btn btn-primary">Add new branch</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  <script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#admin").change(function() {
                readURL(this);
            });
        });
    </script>
