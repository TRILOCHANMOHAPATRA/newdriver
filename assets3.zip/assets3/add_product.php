<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  
  $product=$_POST['product'];
  $brand=$_POST['brand'];
  $model=$_POST['model'];
  
   if(empty($errors)){
     $re=$data-> addproduct($product,$brand,$model);
      if($re){
       header('location:product.php');
      } else {
        header('location:add_product.php');
      }
   } 
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
        <strong>
           
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_product.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Product</label>
                <input type="text" class="form-control" name="product" placeholder="product">
            </div>
            <div class="form-group">
            <label >Brand</label>
                <input type="text" class="form-control" name="brand" placeholder="brand">
            </div>
            <div class="form-group">
            <label >Model</label>
                <input type="text" class="form-control" name="model" placeholder="model">
            </div>
            
            
            <button type="submit" name="add_cat" class="btn btn-primary">Add new product</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  <script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#admin").change(function() {
                readURL(this);
            });
        });
    </script>
