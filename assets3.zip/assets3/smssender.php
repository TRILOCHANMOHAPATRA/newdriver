<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='product';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
         
          
       </strong>
       <a href="profile.php" class="btn btn-info pull-left">logo</a>
       <a href="accountdetels.php" class="btn btn-info pull-left">Account detels</a>
       <a href="products.php" class="btn btn-info pull-left">product</a>
       <a href="smssender.php" class="btn btn-info pull-left">SMS Sender Id</a>
       <a href="terms.php" class="btn btn-info pull-left">terms and condition</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
        <div class="create-job-sheet manage-profile hide" id="smsCnt" style="display: block;">
                                                <h2 class="d-inline-block form-hdg">Sender ID <i class="fas fa-info-circle" data-toggle="tooltip" data-html="true" title="" data-original-title="<p>Sender ID should be 6 characters</p> <p>Ex: SRVCRL</p>"></i></h2>
                                                <ul class="form-list-cntr">
                                                    <li>
                                                        <ul class="row">
                                                            <li class="col-lg-3 col-md-4 col-sm-12 form-list-item select2-custom-cntr">
                                                                <input class="form-list-input" maxlength="6" minlength="6" type="text" id="senderID">
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <ul class="row">
                                                            <li class="col-lg-12 col-md-12 col-sm-12 form-list-item btn-wrpr">
                                                                <input type="button" id="saveSenderID" value="Save" class="form-btn">
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>
        <tbody>
        
          <tr>
          
          </tr>
        <?php ?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>


 
