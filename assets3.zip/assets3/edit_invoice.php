<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
if(isset($_GET['id'])){
    $idd=$_GET['id'];
    $r=$data->couponid2($idd);
    $row2=$r->fetch(PDO::FETCH_ASSOC);
    }
$data=new db;
$table='product_type';
$b='brand';
$m='model';
$product_type=$data->select($table);
$br=$data->select($b);
$mo=$data->select($m);
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['submit'])){
  $jnumber=$_POST['jnumber'];
 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
 $mobile=$_POST['mobile'];
 $amobile=$_POST['amobile'];
 $email=$_POST['email'];
 $address=$_POST['address'];
 $address2=$_POST['address2'];
 $gstin=$_POST['gstin'];
 $type=$_POST['type'];
 $brand=$_POST['brand'];
 $modelname=$_POST['modelname'];
 $modelnumber=$_POST['modelnumber'];
 $color=$_POST['color'];
 $configuration=$_POST['configuration'];
 $password=$_POST['password'];
 $imeino=$_POST['imeino'];
 $imeino2=$_POST['imeino2'];
 $status=$_POST['status'];
 $problem=$_POST['problem'];
  $condition=$_POST['condition'];
 $estimate=$_POST['estimate'];
 $advance=$_POST['advance'];
 $edate=$_POST['edate'];
 $etime=$_POST['etime'];
  $id=1;
  $idd=$_POST['aid'];
  
     $re=$data->editjobsheet($jnumber,$firstname,$lastname,$mobile,$amobile,$email,$address,$gstin,$type,$brand,$modelname,$modelnumber,
     $color,$configuration,$password,$imeino,$imeino2,$problem,$estimate,$condition,$idd);

     
      if($re){
       header('location:list_invoice.php');
      } else {
        header('location:edit_invoice.php');
      }
   } 
 
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
        <strong>
        <span class="glyphicon glyphicon-th"></span>
            <span>Edit Carry in </span>
           </strong>
       
        </div>
        <div class="panel-body">
          <form method="post" action="edit_invoice.php" enctype="multipart/form-data">
          <ul class="form-list-cntr">
                                                        <li class="form-list-item">
                                                            <div>
                                                                <label class="d-block form-list-label">Service Type</label>
                                                                <div>
                                                                <label class="d-block form-list-label">invoice<span class="mandatory-field">*</span></label>  
                                                                <a href="add_invoice.php">
  <input type="radio" style="pointer-events:none;">
</a>
<label class="d-block form-list-label">onsite<span class="mandatory-field">*</span></label>
<a href="add_pickup.php">
  <input type="radio" style="pointer-events:none;">
</a>
<label class="d-block form-list-label">pickup<span class="mandatory-field">*</span></label>
<a href="add_onsite.php">
  <input type="radio" style="pointer-events:none;">
</a>
                                                                </div>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">jobsheet number<span class="mandatory-field">*</span></label>
                                                                    <input type="tel" name="jnumber" value="<?php echo $row2['jobsheet_number']; ?>" class="form-list-input" maxlength="10">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Customer Information</div>
                                                            <ul class="row form-list">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">First Name<span class="mandatory-field">*</span></label>
                                                                   
                                                                    <input type="text" name="firstname" value="<?php echo $row2['firstname'];?>" class="form-list-input float-left customer-first-name" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Last Name</label>
                                                                    <input type="text" name="lastname" value="<?php echo $row2['lastname'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Mobile Number<span class="mandatory-field">*</span></label>
                                                                    <input type="tel" name="mobile" value="<?php echo $row2['mobile_number'];?>" class="form-list-input" maxlength="10">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Alternate Mobile Number</label>
                                                                    <input type="tel" name="amobile" value="<?php echo $row2['alternate_mobile'];?>" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Email name</label>
                                                                    <input placeholder="Enter valname Email name's only" type="text" name="email" value="<?php echo $row2['email_id'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Address</label>
                                                                    <input placeholder="Enter valname Email name's only" type="text" name="address" value="<?php echo $row2['address'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">gstin</label>
                                                                    <input placeholder="Enter valname Email name's only" type="text" name="gstin" value="<?php echo $row2['gstin'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                
																<li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label >Brand</label>
            <select  class="form-control" name="brand" id="brand">
            <option>Select brand</option>
            <?php while($row=$br->fetch(PDO::FETCH_ASSOC)){ ?>
            <option value="<?php echo $row['model_id'];?>"><?php echo $row['brand_name']; ?></option>
            <?php } ?>
           
            </select>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Product Information</div>
                                                            
                                                            <li class="col-lg-3 col-md-4 col-sm-12 form-list-item select2-custom-cntr">
                                                                <label >product Types</label>
            <select  class="form-control" name="type" id="status">
            <option>Select product type</option>
            <?php while($row=$product_type->fetch(PDO::FETCH_ASSOC)){?>
            <option value="<?php echo $row['product_id'] ?>"><?php echo $row['product_name']; ?></option>
            <?php }?>
            </select>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label >model</label>
            <select  class="form-control" name="type" id="status">
            <option>Select modelname</option>
            <?php while($row=$mo->fetch(PDO::FETCH_ASSOC)){ ?>
            <option value="<?php echo $row['model_id'];?>"><?php echo $row['model_name']; ?></option>
           <?php } ?>
            </select>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">modelnumber</label>
                                                                    <input type="text" name="modelnumber" value="<?php echo $row2['modelno'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">color</label>
                                                                    <input type="text" name="color" value="<?php echo $row2['color'];?>" class="form-list-input" maxlength="50">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">configuration</label>
                                                                    <input type="text" name="configuration" value="<?php echo $row2['configuration'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">password</label>
                                                                    <input type="text" name="password" value="<?php echo $row2['password'];?>"  placeholder="i5 Processor, 8GB ram etc." class="form-list-input" maxlength="50">
                                                                    
                                                                    
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">imeino <span class="pattern-icon" name="btnPatternLock"><i class="fa fa-circle"></i></span></label>
                                                                    <input type="text" name="imeino" value="<?php echo $row2['sino'];?>" class="form-list-input" maxlength="20">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label"><span name="si1NoLabel">imeino2</span> 1</label>
                                                                    <input type="text" name="imeino2" value="<?php echo $row2['sino2'];?>" class="form-list-input" maxlength="25">
                                                                </li>
                                                                
                                                                
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label"><span name="si1NoLabel">status</span> 1</label>
                                                                    <input type="text" name="status" class="form-list-input" maxlength="25">
                                                                </li>
                                                                   
                                                                <li  class="col-lg-3 col-md-4 col-sm-12 form-list-item" name="warrantyRefNo">
                                                                    <label class="d-block form-list-label">problem</label>
                                                                    <input type="text" name="problem" value="<?php echo $row2['problem'];?>" class="form-list-input" maxlength="50">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">condition</label>
                                                                    <input type="text" name="condition" value="<?php echo $row2['lastname'];?>" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">estimate</label>
                                                                    <textarea name="estimate"  class="form-list-input" maxlength="50"></textarea>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Estimated Cost (Rs.)</label>
                                                                    <input type="text" name="estimatedCost" value="<?php echo $row2['cost'];?>" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Advance Paname (Rs.)</label>
                                                                    <input type="text" name="advance" value="<?php echo $row2['advance'];?>" class="form-list-input" maxlength="20">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Expected Delivery Date</label>
                                                                    <input type="date" name="edate" value="<?php echo $row2['delivery_date'];?>" class="form-list-input hasDatepicker" maxlength="40" readonly="">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Expected Delivery time</label>
                                                                    <input type="time" name="etime" value="<?php echo $row2['delivery_time'];?>" class="form-list-input hasDatepicker" maxlength="40" readonly="">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                
                                                            
                                                                <input type="hidden" name="aid" value="<?php echo $row2['id']; ?>">
                                                                <button type="submit" name="submit" class="btn btn-primary">Edit</button>
                                                        </li>
                </ul>
  
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>

