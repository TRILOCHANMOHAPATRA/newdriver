<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?>


<?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $page='';
  $data=new db;
  $name='jobsheet';
 $jobsheet=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php
if (!isset ($_GET['page']) ) {  
    $page = 1;  
} else {  
    $page = $_GET['page'];  
}  
$from='2023-09-01';
$to='2023-09-28';
if(isset($_GET['detels'])){
  $from=$_GET['start_date'];
  $to=$_GET['end_date'];
  
}
$d=$data->jobsheetdatewise($from,$to);

$result_per_page=10;
$page_first_result=($page-1) * $result_per_page;
$c=$data->countjobsheet();
$cou=$c->fetch(PDO::FETCH_ASSOC);
$count=$cou['count(*)'];
$numofpage=ceil($count/$result_per_page);
$lastpage=($page_first_result + $result_per_page);
$leclimit=$data->jobsheetlimit($page_first_result,$result_per_page);
?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Refer your friends, Get credits worth Rs. 550 on each one</span><br>
         <button> <a href="https://wa.me/8847862821" class="btn btn-xs " >whatsApp
          <i class="glyphicon glyphicon-whatsApp"></i>
                </a></button>
                <button> <a href="https://www.facebook.com/8847862821" class="btn btn-xs " >facebook
          <i class="glyphicon glyphicon-whatsApp"></i>
                </a></button>
                </button>
                <button> <a href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4ifQ%3D%3D%22%7D" class="btn btn-xs " >twitter
          <i class="glyphicon glyphicon-whatsApp"></i>
                </a></button>
                <button> <a href="https://in.linkedin.com/" class="btn btn-xs " >linkedin
          <i class="glyphicon glyphicon-whatsApp"></i>
                </a></button>
          
       </strong>
      
       <a href="add_invoice.php" class="btn btn-info pull-right">add invoice</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
          <th class="text-center" style="width: 50px;">#</th>
            <th class="text-center" style="width: 50px;">Name</th>
            <th class="text-center" style="width: 15%;"> Email ID</th>
            <th class="text-center" style="width: 15%;">Phone Number</th>
            <th class="text-center" style="width: 15%;">Company Name</th>
            <th class="text-center" style="width: 15%;">Personalised Message</th>
            <th class="text-center" style="width: 15%;">Status</th>
          </tr>
        </thead>
        <tbody>
        
        
         
       </tbody>
      
     </table>
     
    </div>
  </div>
 
 
</div>
<?php include_once('layouts/footer.php'); ?>
<?php 
  if($page>1)
  {
      echo "<a href='list_invoice.php?page=".($page-1)."' class='btn btn-danger'><</a>";
  }
  for($i=1;$i<$numofpage;$i++)
  {
      echo "<a href='list_invoice.php?page=".$i."' class='btn btn-primary'>$i</a>";
  }
  if($i>$page)
  {
      echo "<a href='list_invoice.php?page=".($page+1)."' class='btn btn-danger'>></a>";
  }
             ?>
              </table><div class="dataTables_info" id="example_info" role="status" aria-live="polite">Showing <?php echo $page_first_result;?> to <?php echo $lastpage;?> of <?php echo $count;?> entries</div><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"></div></div>
