<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='product';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
       </strong>
       <a href="profile.php" class="btn btn-info pull-left">logo</a>
       <a href="accountdetels.php" class="btn btn-info pull-left">Account detels</a>
       <a href="products.php" class="btn btn-info pull-left">product</a>
       <a href="smssender.php" class="btn btn-info pull-left">SMS Sender Id</a>
       <a href="terms.php" class="btn btn-info pull-left">terms and condition</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
        <form autocomplete="off">
                                                    <input autocomplete="false" name="hidden" type="text" style="display:none;">
                                                    <ul class="form-list-cntr">
                                                        <li>
                                                            <ul class="row form-list">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">First Name</label>
                                                                    <input type="text" id="firstName" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Last Name</label>
                                                                    <input type="text" id="lastName" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Company</label>
                                                                    <input type="text" id="company" class="form-list-input" maxlength="40">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Address</label>
                                                                    <textarea id="address1" class="form-list-textarea" maxlength="40"></textarea>
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Address</label>
                                                                    <textarea id="address2" class="form-list-textarea" maxlength="40"></textarea>
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Email ID</label>
                                                                    <input disabled="disabled" type="text" id="emailId" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Phone Number</label>
                                                                    <input type="tel" id="phoneNumber" class="form-list-input" maxlength="10">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">City</label>
                                                                    <input name="registerCityName" type="text" id="city" class="form-list-input city-box pac-target-input" placeholder="Enter a location" autocomplete="off">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <!-- <li class='col-lg-3 col-md-4 col-sm-12 form-list-item'>
                                                            <label class='d-block form-list-label'>Tin No.</label>
                                                            <input type='text' id='tinNo' class='form-list-input' maxlength='20' />
                                                            <span class='form-list-input-error'></span>
                                                        </li>
                                                        <li class='col-lg-3 col-md-4 col-sm-12 form-list-item'>
                                                            <label class='d-block form-list-label'>Service Tax No.</label>
                                                            <input type='text' id='serviceTaxNo' class='form-list-input' maxlength='20' />
                                                            <span class='form-list-input-error'></span>
                                                        </li>-->
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">PAN No.</label>
                                                                    <input type="text" id="panNo" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Tax Registration Display Name</label>
                                                                    <input type="text" id="taxRegDisplayName" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Tax Registration Number</label>
                                                                    <input type="text" id="taxRegistrationNumber" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Password</label>
                                                                    <input autocomplete="new-password" type="password" id="oldPassword" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                        <li>
                                                            <div>
                                                                <label for="blockDailyReport" class="custom-control custom-checkbox">
                                                            <input id="blockDailyReport" type="checkbox" class="custom-control-input">
                                                            <span class="custom-control-indicator"></span>
                                                            <span class="custom-control-description">Disable Daily Report Email Notification</span>
                                                        </label>
                                                            </div>
                                                            <div>
                                                                <label for="updatePassword" class="custom-control custom-checkbox">
                                                            <input id="updatePassword" type="checkbox" class="custom-control-input">
                                                            <span class="custom-control-indicator"></span>
                                                            <span class="custom-control-description">Change Password</span>
                                                        </label>
                                                            </div>
                                                            <ul class="row hide" id="newPasswordCntr">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">New Password</label>
                                                                    <input type="password" id="password" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Retype New Password</label>
                                                                    <input type="password" id="retypePassword" class="form-list-input" maxlength="20">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                        <li>
                                                            <ul class="row">
                                                                <li class="col-lg-12 col-md-12 col-sm-12 form-list-item btn-wrpr">
                                                                    <input type="button" id="updateProfile" value="Save" class="form-btn">
                                                                    <input type="button" id="profileCancelBtn" value="Cancel" class="form-cancel-btn">
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </form>
        <tbody>
        
          <tr>
          
          </tr>
        <?php ?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
<script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview-main').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#main").change(function() {
                readURL(this);
            });
        });
    </script>

 
