<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='branch';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>branches</span>
          
       </strong>
       <a href="add_branch.php" class="btn btn-info pull-right">Add New branches</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="text-center" style="width: 50px;">#</th>
            <th class="text-center" style="width: 15%;"> Name</th>
            <th class="text-center" style="width: 15%;">address</th>
            <th class="text-center" style="width: 15%;">City</th>
            <th class="text-center" style="width: 100px;">Contract no</th>
            <th class="text-center" style="width: 100px;">additional contract number</th>
            <th class="text-center" style="width: 100px;">Email id</th>
            <th class="text-center" style="width: 100px;">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php while($row=$userlogin->fetch(PDO::FETCH_ASSOC)){ ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><?php echo $row['name'];?></td>
           <td><?php echo $row['address']?></td>
           <td><?php echo $row['city']?></td>
           <td><?php echo $row['contractno']?></td>
           <td><?php echo $row['additinalno']?></td>
          
           <td><?php echo $row['email_id']?></td>
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_admin.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="glyphicon glyphicon-pencil"></i>
               </a>
                <a href="delete_admin.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="glyphicon glyphicon-remove"></i>
                </a>
                </div>
           </td>
          </tr>
        <?php }?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

 
