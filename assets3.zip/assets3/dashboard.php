<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?>
<?php 
require ('layouts/navbar.php');
$data=new db;

 
?> 
<div class="card-group">
  <div class="card">
    <img src="photos\service.jpeg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <img src="photos\sale.jpeg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <div class="dashoboard-graph-cntr"><div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
                                                <div class="dashboard-graph-hdr clearfix">
                                                    <h2 class="float-left font-weight-bold">Services</h2>
                                                    <select class="float-right align-top" id="serviceJSBCDrpDown">
                                                        <option value="0">All</option>
                                                    <option value="6671">any</option><option value="6673">trilochan mohapatra</option></select>
                                                </div>
                                                <canvas class="hide chartjs-render-monitor" id="servicejsGraph" width="363" height="181" style="display: inline-block; width: 363px; height: 181px;"></canvas>
                                                <div class="loading-graph-cntr text-center" style="display: none;">
                                                    <i class="fas fa-spinner fa-spin"></i>
                                                    <div class="error-text">Loading</div>
                                                </div>
                                                <div class="text-center empty-graph-cntr hide" style="display: none;">
                                                    <i class="fas fa-chart-line"></i>
                                                    <div class="error-text">Not Enough data available</div>
                                                </div>
                                            </div>
      <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
    </div>
  </div>
 
  </div>
</div>
</body>
</html>