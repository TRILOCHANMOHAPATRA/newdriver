<?php include_once('includes/dbconfig.php');
$login = false;
$showError = false;
$data=new db;
?>
<?php
$usern = $_POST['username'];
$pass = $_POST['password'];

  $user_id =$data->authenticate($usern,$pass);
  $user=$user_id->rowCount();
  if($user==1){
    $login = true;
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $usern;
        header("location: home.php");
  } else {
    header('location:index.php');
  }



?>
