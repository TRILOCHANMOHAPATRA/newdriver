<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
if(isset($_GET['id'])){
    $idd=$_GET['id'];
    $r=$data->couponid($idd);
    $row=$r->fetch(PDO::FETCH_ASSOC);
    }
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  $table='branch';
  $name=$_POST['name'];
  $mobile=$_POST['mobile'];
  $email=$_POST['Email'];
  $address=$_POST['address'];
  $id=$_POST['aid'];
     $re=$data->editcostomer($name,$mobile,$email,$address,$id);
      if($re){
       header('location:customer.php');
      } else {
        header('location:edit_costomer.php');
      }
   } 
 
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New branch</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="edit_costomber.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo $row['name']; ?>">
            </div>
            <div class="form-group">
            <label >mobile number</label>
                <input type="number" class="form-control" name="mobile" value="<?php echo $row['mobileno']; ?>">
            </div>
            <div class="form-group">
            <label >Email</label>
                <input type="email" class="form-control" name="Email" value="<?php echo $row['emailid']; ?>">
            </div>
            <div class="form-group">
            <label >address</label>
                <input type="text" class="form-control" name="address" value="<?php echo $row['address']; ?>">
            </div>
            
            <input type="hidden" name="aid" value="<?php echo $row['id']; ?>">
            <button type="submit" name="add_cat" class="btn btn-primary">Edit</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  <script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#admin").change(function() {
                readURL(this);
            });
        });
    </script>
