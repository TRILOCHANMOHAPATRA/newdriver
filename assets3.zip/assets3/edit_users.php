<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}


?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php');
$table='userlogin';
$column='user_id';
if(isset($_GET['id'])){
    $idd=$_GET['id'];
    $r=$data->wselect2($table,$column,$idd);
    $row=$r->fetch(PDO::FETCH_ASSOC);
    } 
?>
<?php
 if(isset($_POST['add_cat'])){
  $mobile=$_POST['mobile'];
  $firstname=$_POST['first'];
  $lastname=$_POST['last'];
  $email=$_POST['email'];
   $iddd=$_POST['id'];
   if(empty($errors)){
     $re=$data->editusers($mobile,$firstname,$lastname,$email,$iddd);
      if($re){
        header('location:customer.php');
      } else {
        header('location:edit_users.php');
      }
   } else {
    header('location:costomer.php');
   }
 }
?>
<?php include_once('layouts/header.php'); ?>

 
   <div class="row">
    <div class="col-md-5">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Edit User</span>
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="edit_users.php" enctype="multipart/form-data">
          <div class="form-group">
            <label >Change Mobile</label>
                <input type="text" class="form-control" name="mobile" value="<?php echo $row['mobile'];?>">
            </div>
            <div class="form-group">
            <label >Change First Name</label>
                <input type="text" class="form-control" name="first" value="<?php echo $row['user_firstname'];?>">
            </div>
            <div class="form-group">
            <label >Change Last Name</label>
                <input type="text" class="form-control" name="last" value="<?php echo $row['user_lastname'];?>">
            </div>
            <div class="form-group">
            <label >Change Emailid</label>
                <input type="text" class="form-control" name="email" value="<?php echo $row['user_emailid'];?>">
            </div>
            <input type="hidden" name="id" value=<?php echo $idd; ?>>
            <button type="submit" name="add_cat" class="btn btn-primary">Edit user</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
