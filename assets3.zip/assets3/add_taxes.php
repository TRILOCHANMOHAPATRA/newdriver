<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  
  $unique=$_POST['unique'];
  $classname=$_POST['class'];
  $rate=$_POST['rate'];
  $subclass=$_POST['subclass'];
  $business=$_POST['business'];
  
   if(empty($errors)){
     $re=$data-> addtaxes($unique,$classname,$rate,$subclass,$business);
      if($re){
       header('location:taxes.php');
      } else {
        header('location:add_product.php');
      }
   } 
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New taxes</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_taxes.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > unique</label>
                <input type="text" class="form-control" name="unique" placeholder="uniqueid">
            </div>
            <div class="form-group">
            <label >class name</label>
                <input type="text" class="form-control" name="class" placeholder="Class name">
            </div>
            <div class="form-group">
            <label >rate</label>
                <input type="number" class="form-control" name="rate" placeholder="rate">
            </div>
            <div class="form-group">
            <label >sub classes</label>
                <input type="text" class="form-control" name="subclass" placeholder="Sub classes">
            </div>
            <div class="form-group">
            <label >Business activity</label>
                <input type="text" class="form-control" name="business" placeholder="Business activity">
            </div>
            
            <button type="submit" name="add_cat" class="btn btn-primary">Add new product</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>

