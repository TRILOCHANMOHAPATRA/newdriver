<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}


?><?php
  require('includes/dbconfig.php');
  $data=new db;
  $orders='orders';
  $order_list='order_list';
  $id='order_id';
  $order=$data->selectdatewise($orders);
  require_once('includes/load.php'); 
?>
<?php include_once('layouts/header.php'); ?>
  <div class="row">
     <div class="col-md-12">
     </div>
     <div class="row">
  <div class="col-md-20">
    <div class="panel panel-default">
    <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>All orders List</span>
       </strong> 
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="text-center" style="width: 50px;">#</th>
            <th>Order </th>
            <th class="text-center" style="width: 10%;">Order Dates</th>
            <th class="text-center" style="width: 10%;">Order Status</th>
            <th class="text-center" style="width: 10%;">Total Payment</th>
            <th class="text-center" style="width: 10%;">Billing</th>
            <th class="text-center" style="width: 10%;">Ship to</th>
            <th class="text-center" style="width: 10%;">Detels</th>
            <th class="text-center" style="width: 100px;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php while($row2=$order->fetch(PDO::FETCH_ASSOC)){ ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><?php echo $row2['order_id'];?></td>
           <td><?php echo $row2['order_date']; ?></td>
           <td><?php echo $row2['order_status']; ?></td>

           
           <td >
            <?php
              echo ($row2['total_payable']* $row2['quantity'])?></td>
           <td><?php echo $row2['billing_address']; ?></td>
           <td><?php echo $row2['shipping_address'];  ?></td>
           <td class="text-center"><?php echo "<a href=ordersdetels.php?id=".$row2['order_id']." class='btn btn-danger'>Detels</a>" ?></td>
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_orders.php?id=<?php echo (int)$row2['order_item_id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="glyphicon glyphicon-pencil"></i>
               </a>
                <a href="delete_orders.php?id=<?php echo (int)$row2['order_item_id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="glyphicon glyphicon-remove"></i>
                </a>
                </div>
           </td>
          </tr>
        <?php }?>
       </tbody>
     </table>
     </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

