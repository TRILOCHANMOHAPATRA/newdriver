<?php
require('includes/dbconfig.php');
$data=new db;
if(isset($_GET['id'])){
    $id=$_GET['id'];   
}
$v=$data->invoice($id);
$result=$v->fetch(PDO::FETCH_ASSOC);

?>
<html>
<head>Receipt of Purchase - <?php  echo $result['jobsheet_number']; ?>
</head>
<body>
<div style="text-align:right;">
        <b>Sender:</b> Phppot
    </div>
    <div style="text-align: left;border-top:1px solid #000;">
        <div style="font-size: 24px;color: #666;">INVOICE</div>
    </div>
<table style="line-height: 1.5;">
    <tr><td><b>Invoice:</b> #<?php echo $result['jobsheet_number']; ?>
        </td>
        <td style="text-align:right;"><b>TIME: <?php echo $result['delivery_time']; ?></b></td>
        <td style="text-align:right;"><b>DATE: <?php echo $result['delivery_date']; ?></b></td>
    </tr>
    <tr><td><b>Name:</b> <?php echo $result['firstname'] .$result['lastname']; ?>
        </td>
       
    </tr>
    <tr><td><b>Mobile number:</b> <?php echo $result['mobile_number']; ?>
        </td>
       
    </tr>
    <tr><td><b>Gstin:</b> <?php echo $result['gstin']; ?>
        </td>
       
    </tr>
    <tr><td><b>Product type:</b> <?php echo $result['product_type']; ?>
        </td>
       
    </tr>
    <tr><td><b>brand:</b> <?php echo $result['brand']; ?>
        </td>
       
    </tr>
    <tr><td><b>Model name:</b> <?php echo $result['model_name']; ?>
        </td>
       
    </tr>
    <tr><td><b>Email id:</b> <?php echo $result['email_id']; ?>
        </td>
       
    </tr>
    <tr><td><b>Address:</b> <?php echo $result['address']; ?>
        </td>
       
    </tr>
   
    <tr>
        <td><b>Condition:</b>
        </td>
        <td style="text-align:right;"><?php echo $result['condition']; ?></td>
    </tr>
<tr>
<td><b>Problem</b></td>
<td style="text-align:right;"><?php echo $result['problem']; ?></td>
</tr>
<tr>
<td><b>Remark</b></td>
<td style="text-align:right;"><?php echo $result['remarks']; ?></td>
</tr>
<tr>
<td><b>Service Types</b></td>
<?php $stype=$result['service_type'];
$s=$data->service($stype);
$service_name=$s->fetch(PDO::FETCH_ASSOC);
?>
<td style="text-align:right;"><?php echo $service_name['service_name']; ?></td>
</tr>
</table>


<?php
?>

<tr style = "font-weight: bold;">
    
    <td style = "text-align:right;">Cost :</td>
    <td style = "text-align:right;"><?php echo $result['cost']; ?></td>
</tr>
<tr style = "font-weight: bold;">
    
    <td style = "text-align:right;">Advance :</td>
    <td style = "text-align:right;"><?php echo $result['advance']; ?></td>
</tr><br>
<tr style = "font-weight: bold;">
    
    <td style = "text-align:right;">total pay now :</td>
    <td style = "text-align:right;"><?php echo $result['cost'] - $result['advance'];?></td>
</tr>
<tr style = "font-weight: bold;">
<td><img src="photos/<?php echo $result['photo'];?>" alt="" style="width:200px" /></td>
    
</tr>

</table></div>
<p><u>Kindly make your payment to</u>:<br/>
Bank: American Bank of Commerce<br/>
A/C: 05346346543634563423<br/>
BIC: 23141434<br/>
</p>
<p><i>Note: Please send a remittance advice by email to vincy@phppot.com</i></p>
</body>
</html>

