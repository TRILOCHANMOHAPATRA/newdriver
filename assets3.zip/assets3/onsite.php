<?php
  require_once('includes/load.php');
?>
<?php include_once('layouts/header.php'); ?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blinkme</title>
</head>
<body style="background-color:white">
<ul class="form-list-cntr">
                                                        <li class="form-list-item service-type-item">
                                                            <div>
                                                                <label class="d-block form-list-label">Service Type</label>
                                                                <span id="serviceModeConfirm" class="form-list-dtls-val">PICKUP</span>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Jobsheet Number Sequence</label>
                                                                    <span id="sequenceListConfirm" class="form-list-dtls-val">DEFAULT-JOBSHEET1</span>
                                                                </div>
                                                                <div class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Jobsheet Number</label>
                                                                    <span id="customInvoiceNoConfirm" class="form-list-dtls-val">1JS1</span>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Customer Information</div>
                                                            <ul class="row form-list">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">First Name:</label>
                                                                    <span id="firstNameConfirm" class="form-list-dtls-val">trilochan</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Last Name:</label>
                                                                    <span id="lastNameConfirm" class="form-list-dtls-val">mohapatra</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Mobile Number:</label>
                                                                    <span id="phoneNumberConfirm" class="form-list-dtls-val">8847862821</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Alternate Mobile Number:</label>
                                                                    <span id="alternatePhoneNumberConfirm" class="form-list-dtls-val">8847862821</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Email ID:</label>
                                                                    <span id="emailIdConfirm" class="form-list-dtls-val">trilochanmohapatra12345@gmail.com</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Address:</label>
                                                                    <span id="address1Confirm" class="form-list-dtls-val form-val-spaced">bhubaneswer</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Address:</label>
                                                                    <span id="address2Confirm" class="form-list-dtls-val form-val-spaced">bhubaneswer</span>
                                                                </li>
                                                                 <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">GSTIN:</label>
                                                                    <span id="taxRegistrationNumberConfirm" class="form-list-dtls-val">aaa</span>
                                                                </li>

                                                            </ul>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Product Information</div>
                                                            <ul class="row">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Product Type</label>
                                                                    <span id="productTypeConfirm" class="form-list-dtls-val">Laptop</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Brand:</label>
                                                                    <span id="brandConfirm" class="form-list-dtls-val">HCL</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Model:</label>
                                                                    <span id="modelNameConfirm" class="form-list-dtls-val">HP 15q-by002ax</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Model Number:</label>
                                                                    <span id="modelNumberConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Colour of the product:</label>
                                                                    <span id="deviceColorConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Product Configuration</label>
                                                                    <span id="deviceConfConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="d-block form-list-label">Password/Passcode/Patten Lock</label>
                                                                    <span id="passcodeConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label id="productTypeNameConfirm" class="form-list-dtls-label"><span id="si1NoLabelConfirm">SI No.</span> 1</label>
                                                                    <span id="imeaNoConfirm" class="form-list-dtls-val">122</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label"><span id="si2NoLabelConfirm">SI No.</span> 2</label>
                                                                    <span id="imeaNo1Confirm" class="form-list-dtls-val">122</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Product Status</label>
                                                                    <span id="statusConfirm" class="form-list-dtls-val">WARRANTY</span>
                                                                </li>
                                                                <li style="" class="col-lg-3 col-md-4 col-sm-12 form-list-item" id="warrantyRefCnfrmWrpr">
                                                                    <label class="d-block form-list-label">Warranty Reference</label>
                                                                    <span id="warrantyRefConfirm" class="form-list-dtls-val form-val-spaced">any</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="form-list-dtls-label">Problem reported by the customer</label>
                                                                    <span id="reportedFaultConfirm" class="form-list-dtls-val form-val-spaced">No internet
Laptop running slowly.
</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Condition of the product</label>
                                                                    <span id="physicalConditionConfirm" class="form-list-dtls-val form-val-spaced"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Estimated Cost (Rs.):</label>
                                                                    <span id="estimatedCostConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Advance Paid (Rs.):</label>
                                                                    <span id="advancePaidConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Expected Delivery Date:</label>
                                                                    <span id="expectedDeliveryDateValConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Expected Delivery Time</label>
                                                                    <span id="expectedDeliveryTimeValConfirm" class="form-list-dtls-val"></span>
                                                                </li>
                                                                <li class="col-lg-12 col-md-12 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="form-list-dtls-label">Received Items</label>
                                                                    <div class="position-relative table-responsive">
                                                                        <table id="receivedItemsListConfirm" class="job-lists-table table mobile-table">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th class="item-hdr item-desc">Name</th>
                                                                                    <th class="item-hdr item-desc">Reference No.</th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody id="receivedItemsTableConfirm">

                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <ul class="row">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Remarks</label>
                                                                    <span id="remarksConfirm" class="form-list-dtls-val">any</span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" style="display: none;">
                                                                    <label class="d-block form-list-label">Assign Operator/Technician</label>
                                                                    <span id="assigneeConfirm" class="form-list-dtls-val">-</span>
                                                                </li>
                                                            </ul>
                                                            <ul class="row">
                                                                <li class="col-lg-12 col-md-12 col-sm-12 btn-wrpr">
                                                                    <input type="button" id="createJobSheetBtnConfirm" value="confirm" class="form-btn">
                                                                    <input type="button" id="createJobSheetBtnEdit" value="edit" class="form-cancel-btn">
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
</body>
</html>
<?php include_once('layouts/footer.php'); ?>
