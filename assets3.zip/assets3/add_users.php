<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  
  $role=$_POST['role'];
  $name=$_POST['name'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
   if(empty($errors)){
     $re=$data->adduser($role,$name,$email,$phone);
      if($re){
       header('location:users.php');
      } else {
        header('location:add_users.php');
      }
   } 
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New user</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_users.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Role </label>
                <input type="text" class="form-control" name="role" placeholder="Role">
            </div>
            <div class="form-group">
            <label >Name</label>
                <input type="text" class="form-control" name="name" placeholder="Name">
            </div>
            <div class="form-group">
            <label >Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email">
            </div>
            <div class="form-group">
            <label >phone_number</label>
                <input type="number" class="form-control" name="phone" placeholder="phone number">
            </div>
            
            
            <button type="submit" name="add_cat" class="btn btn-primary">Add new user
            </button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  