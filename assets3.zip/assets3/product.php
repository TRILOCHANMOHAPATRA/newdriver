<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='product';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>product</span>
          
       </strong>
       <a href="add_product.php" class="btn btn-info pull-right">Add New product</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="text-center" style="width: 50px;">#</th>
            <th class="text-center" style="width: 15%;"> product</th>
            <th class="text-center" style="width: 15%;">brand</th>
            <th class="text-center" style="width: 15%;">model</th>
            <th class="text-center" style="width: 15%;">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php while($row=$userlogin->fetch(PDO::FETCH_ASSOC)){ ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><?php echo $row['product'];?></td>
           <td><?php echo $row['brand']?></td>
           <td><?php echo $row['model_no']?></td>
          
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_product.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="glyphicon glyphicon-pencil"></i>
               </a>
                <a href="delete_product.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="glyphicon glyphicon-remove"></i>
                </a>
                </div>
           </td>
          </tr>
        <?php }?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

 
