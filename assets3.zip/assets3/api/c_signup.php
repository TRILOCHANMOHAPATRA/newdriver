<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once('db.php');
require('mail.php');
$mail=new mail;
$data = new db;
$json = file_get_contents('php://input');
$obj = json_decode($json, true);
$table = 'userlogin';
$mobile = $obj['mobile'];
$password = $obj['password'];
$userfirstname = $obj['firstname'];
$userlastname = $obj['lastname'];
$userimage = $obj['image'];
$emailid = $obj['emailid'];
// Encrypt the password using password_hash()
$hashed_password = sha1($password);
// Check if mobile number already exists
if ($data->checkMobileExists($mobile)) {
    $response['message'] = "Mobile number already exists";
    $response['status'] = false;
 $returnArr = array($response);        
} else {
    // Check if email is not empty and then check for duplicate email
    if (!empty($emailid) && $data->checkEmailExists($emailid)) {
        $response['message'] = "Email already exists";
        $response['status'] = false;
    } else {
        // Insert new user record
        try {
            $resultant = $data->insert1($mobile, $hashed_password, $userfirstname, $userlastname, $userimage, $emailid);
            if ($resultant) {
                // Get the newly inserted user data
                $user_data = $data->getUserDataByMobile($mobile);

                $response['user_id'] = $user_data['user_id'];
                $response['user_firstname'] = $user_data['user_firstname'];
                $response['user_lastname'] = $user_data['user_lastname'];
                $response['mobile'] = $user_data['mobile'];
                $response['user_image'] = $user_data['user_image'];
                $response['user_emailid'] = $user_data['user_emailid'];
                $response['address_id'] = $user_data['address_id'];
                $response['status'] = true;
              $m=$mail->sendWelcomeEmail($emailid, $userfirstname, $userlastname, $mobile);
              $response['message'] = "Signup successful";
            } else 
            {
                $response['status'] = false;
            $response['message'] = "Error inserting user record";
   
            }
        } catch (PDOException $e) {
        
            $response['message'] = "Error: " . $e->getMessage();
            $response['status'] = false;
    
        }
    }
}

echo json_encode($response);
?>
