<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('db.php');
$data = json_decode(file_get_contents('php://input'), true);

// check if user_id is provided
if (empty($data['user_id'])) {
    http_response_code(400);
    echo json_encode(array('message' => 'Missing user_id parameter', 'status' => false));
    exit;
}

// connect to the database
$db = new db();
$conn = $db->getConnection();

// prepare the SQL query to fetch the cart items for the given user
$sql = "SELECT ci.*, p.product_name, p.product_description, p.unit_id, p.subcategory_id, p.brand_id, p.volume, p.discount, p.category_id, p.product_status, p.product_image, p.product_price, p.discounted_price, p.product_image, u.unit_name 
        FROM cart_item ci
        LEFT JOIN product_list p ON ci.product_id = p.product_id
        LEFT JOIN unit u ON p.unit_id = u.unit_id
        WHERE ci.user_id = :user_id";

// execute the query
$stmt = $conn->prepare($sql);
$stmt->bindValue(':user_id', $data['user_id'], PDO::PARAM_INT);
$stmt->execute();

// fetch the results and store them in an array
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if any cart items are found for the given user_id
if (empty($cart_items)) {
    http_response_code(404);
    echo json_encode(array('message' => 'Cart items not found for the given user', 'status' => false));
    exit;
}

// Check if the user_id in the cart_item table matches the user_id in the request
$cart_user_id = $cart_items[0]['user_id'];
if ($cart_user_id != $data['user_id']) {
    http_response_code(400);
    echo json_encode(array('message' => 'User ID in request does not match user ID in cart items table', 'status' => false));
    exit;
}

// Calculate the subtotal by adding up the prices of all items in the cart
$sub_total = 0 ;
foreach ($cart_items as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];

    // Retrieve the price of the product from the product_list table
    $query = "SELECT discounted_price FROM product_list WHERE product_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(1, $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Add the product discounted_price to the subtotal
    if ($result) {
       $sub_total += $result['discounted_price'] * $quantity;
    }
}
// Apply coupon code if provided by the user
if (isset($data['coupon_code']) && !empty($data['coupon_code'])) {
    $coupon_code = $data['coupon_code'];

// Retrieve the coupon from the coupon table
$query = "SELECT * FROM coupon WHERE coupon_code = ?";
$stmt = $conn->prepare($query);
$stmt->bindParam(1, $coupon_code, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Apply the coupon discount to the subtotal
if ($result) {
    $discount_amount = $result['discount_amount'];
    $discount_type = $result['discount_type'];
    if ($discount_type == "percentage") {
        $discount = $sub_total * $discount_amount / 100;
    } else {
        $discount = $discount_amount;
    }
  //  $sub_total = $sub_total;
} else {
    $discount = 0;
}
} else {
    $discount = 0;
}
// Apply additional fee if applicable
$additional_fees = array(); // initialize an empty array for additional fees
$query = "SELECT additionalfee_name, additionalfee_amount, min_amount FROM additional_fee WHERE additionalfee_type = 'All' OR (additionalfee_type = 'product' AND product_id IN (". implode(',', array_unique(array_column($cart_items, 'product_id'))) .")) OR (additionalfee_type = 'category' AND category_id IN (". implode(',', array_unique(array_column($cart_items, 'category_id'))) .")) OR (additionalfee_type = 'subcategory' AND subcategory_id IN (". implode(',', array_unique(array_column($cart_items, 'subcategory_id'))) ."))";
$stmt = $conn->prepare($query);
$stmt->execute();

// Fetch the results and add them to the additional fees array
while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $additional_fee_name = $result['additionalfee_name'];
    $additional_fee_amount = $result['additionalfee_amount'];
    $min_amount = $result['min_amount'];
    if ($sub_total < $min_amount) {
        $additional_fees[$additional_fee_name] = $additional_fee_amount;
    }
}

// Check if additional fees are applicable based on min_amount
foreach ($additional_fees as $fee_name => $fee_amount) {
    $query = "SELECT min_amount FROM additional_fee WHERE additionalfee_name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(1, $fee_name, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result && $sub_total > $result['min_amount']) {
        unset($additional_fees[$fee_name]);
    }
}

// Calculate the total additional fee
$additional_fee = array_sum($additional_fees);

// Add the additional fees to the subtotal
//$sub_total = $sub_total + $additional_fee;

// Calculate the total payable amount by adding the subtotal and additional fee
$total_payable = $sub_total - $discount + $additional_fee;

// Return the billing details in JSON format
$response = array(
    'status' => true,
    'message' => 'Billing details retrieved successfully',
    'subtotal' => $sub_total,
    'discount' => $discount,
    'additional_fees' => $additional_fees,
    'total_payable' => $total_payable
);
echo json_encode($response);
?>