<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once('db.php');
require('mail.php');
$mail = new mail;
$u = 'update successfully';
    require 'vendor/autoload.php';

    use PayPalCheckoutSdk\Core\PayPalHttpClient;
    use PayPalCheckoutSdk\Core\SandboxEnvironment;
    use PayPalCheckoutSdk\Orders\OrdersCreateRequest;

// Decode the request payload as JSON
$data = json_decode(file_get_contents('php://input'), true);

// Get the variables from the request payload
$user_id = $data['user_id'];
$bill_id = $data['bill_id'];
$payment_id = $data['payment_id'];
$payment_status = $data['payment_status'];
$order_status = $data['order_status'];
$coupon_id = isset($data['coupon_id']) ? $data['coupon_id'] : 0; // Treat coupon_id as 0 if empty
$address_id = $data['address_id'];
$drop_outside = $data['drop_outside'];
$ring_bell = $data['ring_bell'];
$call_while_delivery = $data['call_while_delivery'];
$delivery_instructions = $data['delivery_instructions'];

// Connect to the database
$db = new db();
$conn = $db->getConnection();

// Get the cart_id from the bill table
$select_cart_query = "SELECT cart_id FROM bill WHERE bill_id = ?";
$stmt = $conn->prepare($select_cart_query);
$stmt->execute([$bill_id]);
$cart_id = $stmt->fetch(PDO::FETCH_ASSOC)['cart_id'];

// Get the total_payable from the bill table
$select_cart_query = "SELECT total_payable FROM bill WHERE bill_id = ?";
$stmt = $conn->prepare($select_cart_query);
$stmt->execute([$bill_id]);
$total_payable = $stmt->fetch(PDO::FETCH_ASSOC)['total_payable'];


// Check if the payment mode is cash on delivery
if ($payment_id == '2') {
    // Check if an entry for this bill_id, cart_id, and user_id already exists
    $select_query = "SELECT * FROM order_list WHERE user_id = ? AND cart_id = ? AND bill_id = ?";
    $stmt = $conn->prepare($select_query);
    $stmt->execute([$user_id, $cart_id, $bill_id]);
    $existing_order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_order) {
        // Update the existing order
        $update_query = "UPDATE order_list SET payment_id = ?, payment_status = ?, order_status = ? WHERE order_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->execute([$payment_id, $payment_status, $order_status, $existing_order['order_id']]);
        if ($stmt->rowCount() > 0) {
            // Update the cart status
            $update_cart_query = "UPDATE carts SET status = 3 WHERE cart_id = ?";
            $stmt = $conn->prepare($update_cart_query);
            $stmt->execute([$cart_id]);
            $response = array(
                'status' => true,
                'message' => 'Order updated successfully'
            );
        } else {
            $response = array(
                'status' => false,
                'message' => 'Error updating order'
            );
        }
    } else {
        // Insert the order into the order_list table
        $insert_query = "INSERT INTO order_list (user_id, address_id, cart_id, bill_id, payment_id, payment_status, drop_outside, ring_bell, call_while_delivery, delivery_instructions, order_status, coupon_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->execute([$user_id, $address_id, $cart_id, $bill_id, $payment_id, $payment_status, $drop_outside, $ring_bell, $call_while_delivery, $delivery_instructions, $order_status, $coupon_id]);
        if ($stmt->rowCount() > 0) {
            // Update the cart status
            $update_cart_query = "UPDATE carts SET status = 3 WHERE cart_id = ?";
            $stmt = $conn->prepare($update_cart_query);
            $stmt->execute([$cart_id]);

            // Retrieve the user_firstname and user_emailid from the userlogin table
            $select_user_query = "SELECT user_firstname, user_emailid FROM userlogin WHERE user_id = ?";
            $stmt = $conn->prepare($select_user_query);
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            $response = array(
                'status' => true,
                'message' => 'Order placed successfully'
            );
            
            // Get the last inserted order_id for the specific user_id
    $select_order_id_query = "SELECT order_id FROM order_list WHERE user_id = ? ORDER BY order_id DESC LIMIT 1";
    $stmt = $conn->prepare($select_order_id_query);
    $stmt->execute([$user_id]);
    $order_id = $stmt->fetchColumn();


            // Send order confirmation email
            $success = $mail->sendOrderConfirmationEmail($user['user_firstname'], $user['user_emailid'], $order_id);
            if ($success) {
                $response['email_status'] = true;
                $response['email_message'] = 'Order confirmation email sent successfully';
            } else {
                $response['email_status'] = false;
                $response['email_message'] = 'Error sending order confirmation email';
            }
        } else {
            $response = array(
                'status' => false,
                'message' => 'Error placing order'
            );
        }
    }
} elseif ($payment_id == '3') { // Payment mode is PayPal

   // Set up your PayPal API credentials
$paypalConfig = [
    'client_id' => 'AXUcMjooXZsR6xzhmoVGD6PielHGa0kTX2oPm5gL2aiHpugMgTM9xv98DM8XybxXF7lRk4X6dXbKljbF',
    'secret' => 'EDCW0Uqa-vLZym3YifWpLdOTA6R9Bz0q7xILXARMd_pnDG_YsZoBKy1bd0jUK1CZkWpxQqonmrb-uCUa',
    'settings' => [
        'mode' => 'sandbox', // Change to 'live' for production mode
        'http.ConnectionTimeOut' => 30,
        'log.LogEnabled' => true,
        'log.FileName' => _DIR_ . '/PayPal.log',
        'log.LogLevel' => 'FINE',
    ],
];

// Include the PayPal SDK


    // Create a PayPal client with the provided credentials
    $environment = new SandboxEnvironment($paypalConfig['client_id'], $paypalConfig['secret']);
    $client = new PayPalHttpClient($environment);

    // Create a new PayPal order
    $request = new OrdersCreateRequest();
    $request->headers["prefer"] = "return=representation";
    $request->body = [
        'intent' => 'CAPTURE',
        'purchase_units' => [[
            'amount' => [
                'currency_code' => 'EUR',
                'value' => $total_payable, // The amount you want to charge from the bill table's total_payable column
            ],
        ]],
        'application_context' => [
            'cancel_url' => 'http://example.com/cancel',
            'return_url' => 'http://example.com/success',
        ],
    ];

   try {
    // Send the request to PayPal API
    $apiResponse = $client->execute($request);

    // Get the PayPal order ID
    $orderId = $apiResponse->result->id;

    // Redirect the user to PayPal for payment
    $approvalLink = null;
    foreach ($apiResponse->result->links as $link) {
        if ($link->rel == 'approve') {
            $approvalLink = $link->href;
            break;
        }
    }

    if ($approvalLink) {
        // Include the approval link in the API response
        $response['paypal_approval_link'] = $approvalLink;
    } else {
        $response = array(
            'status' => false,
            'message' => 'Could not create PayPal order.'
        );
    }
} catch (Exception $e) {
    $response = array(
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    );
}
}

// Check if payment is completed
if ($payment_status == 'COMPLETED') {
    // Check if an entry for this bill_id, cart_id, and user_id already exists
    $select_query = "SELECT * FROM order_list WHERE user_id = ? AND bill_id = ?";
    $stmt = $conn->prepare($select_query);
    $stmt->execute([$user_id, $bill_id]);
    $existing_order = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_order) {
        // Update the existing order
        $update_query = "UPDATE order_list SET payment_id = ?, payment_status = ?, order_status = ?, coupon_id = ? WHERE order_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->execute([$payment_id, $payment_status, $order_status, $coupon_id, $existing_order['order_id']]);
        if ($stmt->rowCount() > 0) {
            // Update the cart status
            $update_cart_query = "UPDATE carts SET status = 3 WHERE cart_id = ?";
            $stmt = $conn->prepare($update_cart_query);
            $stmt->execute([$cart_id]);
            $response = array(
                'status' => true,
                'message' => 'Order updated successfully'
            );
        } else {
            $response = array(
                'status' => false,
                'message' => 'Error updating order'
            );
        }
    } else {
        // Insert the order into the order_list table
        $insert_query = "INSERT INTO order_list (user_id, address_id, cart_id, bill_id, payment_id, payment_status, drop_outside, ring_bell, call_while_delivery, delivery_instructions, order_status, coupon_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->execute([$user_id, $address_id, $cart_id, $bill_id, $payment_id, $payment_status, $drop_outside, $ring_bell, $call_while_delivery, $delivery_instructions, $order_status, $coupon_id]);
        if ($stmt->rowCount() > 0) {
            // Update the cart status
            $update_cart_query = "UPDATE carts SET status = 3 WHERE cart_id = ?";
            $stmt = $conn->prepare($update_cart_query);
            $stmt->execute([$cart_id]);
            $response = array(
                'status' => true,
                'message' => 'Order placed successfully'
            );

            // Retrieve the user_firstname and user_emailid from the userlogin table
            $select_user_query = "SELECT user_firstname, user_emailid FROM userlogin WHERE user_id = ?";
            $stmt = $conn->prepare($select_user_query);
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Get the last inserted order_id for the specific user_id
            $select_order_id_query = "SELECT order_id FROM order_list WHERE user_id = ? ORDER BY order_id DESC LIMIT 1";
            $stmt = $conn->prepare($select_order_id_query);
            $stmt->execute([$user_id]);
            $order_id = $stmt->fetchColumn();

            // Send order confirmation email
            $success = $mail->sendOrderConfirmationEmail($user['user_firstname'], $user['user_emailid'], $order_id);
            if ($success) {
                $response['email_status'] = true;
                $response['email_message'] = 'Order confirmation email sent successfully';
            } else {
                $response['email_status'] = false;
                $response['email_message'] = 'Error sending order confirmation email';
            }
        } else {
            $response = array(
                'status' => false,
                'message' => 'Error placing order'
            );
        }
    }
}

// If a coupon was applied, update the coupon usage
if ($coupon_id) {
    // Check if an entry for this user_id and coupon_id already exists
    $select_coupon_query = "SELECT * FROM coupon_usage WHERE user_id = ? AND coupon_id = ?";
    $stmt = $conn->prepare($select_coupon_query);
    $stmt->execute([$user_id, $coupon_id]);
    $existing_coupon_usage = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_coupon_usage) {
        // Update the existing coupon usage
        $update_coupon_query = "UPDATE coupon_usage SET usage_count = ? WHERE user_id = ? AND coupon_id = ?";
        $usage_count = $existing_coupon_usage['usage_count'] + 1;
        $stmt = $conn->prepare($update_coupon_query);
        $stmt->execute([$usage_count, $user_id, $coupon_id]);
    } else {
        // Insert a new entry in the coupon_usage table
        $insert_coupon_query = "INSERT INTO coupon_usage (user_id, coupon_id, usage_count) VALUES (?, ?, 1)";
        $stmt = $conn->prepare($insert_coupon_query);
        $stmt->execute([$user_id, $coupon_id]);
    }
}

// Send the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>