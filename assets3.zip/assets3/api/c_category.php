<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='category_list';
  $cid='category_id';
  $id=$obj['category_id'];
    $resultant=$data->select($table,$cid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response['categoryid']=$row['category_id'];
        $response['category']=$row['category_name'];
        $response['image']=$row['category_image'];
        $response['discription']=$row['category_description'];
        $response['status']=$row['cat_status'];
      $response['message']="category successfully match";
    }
  }
    else{
      $response['message']="Wrong credentials";
    } 
  echo json_encode($response);   
?>