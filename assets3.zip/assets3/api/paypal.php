<?php 
// Include configuration file 
include_once 'db.php'; 
$paypal_email='blinkme.de@gmail.com';
$paypalcurrency='USD';
$amount=100;
?>              
<body onload="setTimeout(function() { document.frm1.submit() })">
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" name="frm1">
    <input type="hidden" name="business" value="<?php echo $paypal_email; ?>">
   <input type="hidden" name="amount" value='<?php echo $amount;?>' />
   <input type='hidden' name='cancel_return' value='http://localhost/paypal_integration_php/cancel.php'>
			<input type='hidden' name='return' value='http://localhost/paypal_integration_php/success.php'>	
</form>
</body>


