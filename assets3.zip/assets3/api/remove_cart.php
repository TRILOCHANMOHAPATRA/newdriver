<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='cart';
  $column1='user_id';
  $column2='product_id';
  $user_id=$obj['user_id'];
  $product_id=$obj['product_id'];
    $resultant=$data-> deletecart($table,$column1,$user_id,$column2,$product_id);
    if($resultant){
        $response['message']="remove cart sucessfully"; 
        $response['status']=true;
  }
  else{
    $response['message']="cart not remove";
    $response['status']=false;
  }

  echo json_encode($response);  
?>