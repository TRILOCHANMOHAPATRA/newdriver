<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$params = json_decode(file_get_contents('php://input'), true);
$conditions = array();
if (empty(array_filter($params))) {
    http_response_code(400);
    echo json_encode(array('error' => 'All parameters are blank', 'status' => false));
    exit;
}
if (!empty($params['category_id'])) {
    $conditions[] = 'category_id = ' . $db->quote($params['category_id']);
}

if (!empty($params['subcategory_id'])) {
    $conditions[] = 'subcategory_id = ' . $db->quote($params['subcategory_id']);
}

if (!empty($params['search'])) {
    $conditions[] = 'product_name LIKE ' . $db->quote('%' . $params['search'] . '%');
}

if (!empty($params['start_price'])) {
    $conditions[] = 'product_price >= ' . $db->quote($params['start_price']);
}

if (!empty($params['end_price'])) {
    $conditions[] = 'product_price <= ' . $db->quote($params['end_price']);
}

if (!empty($params['brand_id'])) {
    $conditions[] = 'brand_id = ' . $db->quote($params['brand_id']);
}

if (!empty($params['volume'])) {
    $conditions[] = 'volume LIKE ' . $db->quote('%' . $params['volume'] . '%');
}

 if (!empty($params['user_id'])) {
    $conditions[] = 'user_id = ' . $db->quote($params['user_id']);
}

if (!empty($params['favorite'])) {
    $conditions[] = 'favorite = ' . $db->quote($params['favorite']);
}

$sql = 'SELECT * FROM product_list';
if (!empty($conditions)) {
    $sql .= ' WHERE ' . implode(' AND ', $conditions);
}


$stmt = $db->query($sql);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$returnArr = array( "product_count"=>$results->count(),"product_list"=>$response,"status"=>true,"ResponseMsg"=>"product  List Founded!");
echo json_encode($returnArr);
?>