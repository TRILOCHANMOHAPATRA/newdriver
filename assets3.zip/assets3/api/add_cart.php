<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $user_id=$obj['user_id'];
  $product_id=$obj['product_id'];
  $quantity=$obj['quantity'];
  
  try {
    $resultant=$data-> insertcart($user_id,$product_id,$quantity);
    if($resultant){
        $response['message']="insert cart sucessfully"; 
        $response['status']=true;
  }}
  catch (PDOException $e) {
    $response['message']="cart already exist";
    $response['status']=false;
  }

  echo json_encode($response);  
?>