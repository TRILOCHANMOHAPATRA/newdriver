<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $country=$obj['country'];
  $state=$obj['state'];
  $city=$obj['city'];
  $pincode=$obj['pincode'];
  $streetname=$obj['streetname'];
  $housenumber=$obj['housenumber'];
  $status=$obj['status'];
  $user_id=$obj['user_id'];
  try {
    $resultant=$data->insertaddress($country,$state,$city,$pincode,$streetname,$housenumber,$status,$user_id);
    if($resultant){
        $response['message']="insert address sucessfully"; 
        $response['status']=true;
  }}
  catch (PDOException $e) {
    $response['message']="address already exist";
    $response['status']=false;
  }

  echo json_encode($response);  
?>