<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='subcategory';
  $sid='category_id';
  $id=$obj['categoryid'];
    $resultant=$data->select($table,$sid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response['id']=$row['subcategory_id'];
        $response['name']=$row['subcategory_name'];
        $response['description']=$row['subcategory_description'];
        $response['image']=$row['subcategory_image'];
        $response['status']=$row['status'];
      $response['message']="product successfully match";
    }
  }
    else{
      $response['message']="Wrong credentials";
    } 
  echo json_encode($response);   
?>