<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='subcategory';
  $cat=' category_id';
  $id=$obj['categoryid'];
    $resultant=$data->select($table,$cat,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=
       $row;
    }
    $returnArr = array("subcategory_list"=>$response,"status"=>true,"ResponseMsg"=>"subategory  List Founded!");
  }
    else{
      $returnArr = array("status"=>false,"ResponseMsg"=>"subcategory  List not Founded!");
    } 
  echo json_encode( $returnArr);   
?>