<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='product_list';
  $category=$obj['category_id'];
  $subcategory=$obj['subcategory_id'];
  $product=$obj['search'];
  $start=$obj['start_price'];
  $end=$obj['end_price'];
  $brand=$obj['brand_id'];
  if (empty($obj) && empty($obj['subcategory_id']) && empty($obj['search']) && empty($obj['start_price']) && empty($obj['end_price'])) {
    
    echo json_encode(['message' => 'At  one search parameter is required']);
    exit;
}
if (!empty($obj['category_id']) && empty($obj['subcategory_id']) && empty($obj['search']) && empty($obj['start_price']) && empty($obj['end_price'])) {
  
  echo json_encode(['message' => 'get product detels']);
  exit;
}
if (empty($obj['category_id']) && !empty($obj['subcategory_id']) && empty($obj['search']) && empty($obj['start_price']) && empty($obj['end_price'])) {
  echo json_encode(['message' => 'get product detels']);
  exit;
}
if (empty($obj['category_id']) && empty($obj['subcategory_id']) && !empty($obj['search']) && empty($obj['start_price']) && empty($obj['end_price'])) {
  
  echo json_encode(['message' => 'get product detels']);
  exit;
}
if (empty($obj['category_id']) && empty($obj['subcategory_id']) && empty($obj['search']) && !empty($obj['start_price']) && empty($obj['end_price'])) {
  
  echo json_encode(['message' => 'get product detels']);
  exit;
}
if (empty($obj['category_id']) && empty($obj['subcategory_id']) && empty($obj['search']) && empty($obj['start_price']) && !empty($obj['end_price'])) {
  
  echo json_encode(['message' => 'get product detels']);
  exit;
}
if (empty($obj['category_id']) && empty($obj['subcategory_id']) && empty($obj['search']) && empty($obj['start_price']) && empty($obj['end_price']) && !empty($obj['brand_id'])) {
  
  echo json_encode(['message' => 'get product detels']);
  exit;
}
else{

  
    $resultant=$data->allselect3($table,$category,$subcategory,$product,$start,$end,$brand);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=$row;
    }
    $returnArr = array( "product_count"=>$resultant->rowCount(),"product_list"=>$response,"status"=>true,"ResponseMsg"=>"product  List Founded!");
  }
    else{     
      $returnArr = array("status"=>false,"ResponseMsg"=>"product  List Not Founded!");
    }
  }
  echo json_encode($returnArr);  
?>