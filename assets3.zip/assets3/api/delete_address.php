
<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='product_list';
  $address_id=$obj['address_id'];
  $user_id=$obj['user_id'];
  
$resultant = $data->deleteaddress($address_id,$user_id);
if($resultant){
	
  $returnArr = array("status"=>true,"ResponseMsg"=>"delete status sucessfully");
}
  else{
	$returnArr = array("status"=>false,"ResponseMsg"=>"delete List not sucessfully");
  } 
echo json_encode( $returnArr);   
?>