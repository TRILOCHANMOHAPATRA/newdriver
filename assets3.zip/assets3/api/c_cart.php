<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='cart';
  $cid='user_id';
  $id=$obj['user_id'];
    $resultant=$data->select($table,$cid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response=$row;
      $response['message']="cart successfully match";
    }
  }
    else{
        
      $response['message']="Wrong credentials";
    } 
  echo json_encode($response);   
?>