

<?php 
require 'db.php';
$data=new db;
header('Content-type: text/json');
$table='category_list';
$resultant = $data->allselect($table);
if($resultant->rowCount()>0){
	while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
	  $response[]=
	 $row;
  }
  $returnArr = array("category_list"=>$response,"status"=>"true","ResponseMsg"=>"category  List Founded!");
}
  else{
	$returnArr = array("status"=>"false","ResponseMsg"=>"category  List not Founded!");
  } 
echo json_encode( $returnArr);   
?>