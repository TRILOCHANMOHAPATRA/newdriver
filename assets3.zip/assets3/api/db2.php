<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if (session_status() == PHP_SESSION_NONE) {
   session_start();
}

define('DBHost', 'mysql:host=localhost;dbname=ra2');
define('DBUser', 'root');
define('DBPassword','');

class db
{
    private $sb;

    public function __construct()
    {
        $this->sb = new PDO(DBHost, DBUser, DBPassword);
        $this->sb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
      public function getConnection()
    {
        return $this->sb;
    }
    
    
    public function apiadmin($user, $pass)
    {
        $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE mobile = :user AND password = :pass");
        $stmt->bindParam(':user', $user, PDO::PARAM_STR);
        $stmt->bindParam(':pass', $pass, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

  public function getUserByMobile($mobile)
    {
        $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE mobile = :mobile");
        $stmt->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

public function getUserDataByMobile($mobile)
    {
        $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE mobile = :mobile LIMIT 1");
        $stmt->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getUserById($user_id)
    {
        $stmt = $this->sb->prepare('SELECT * FROM userlogin WHERE user_id = :user_id');
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function select($table, $sid, $id)
    {
    $stmt = $this->sb->prepare("SELECT * FROM $table WHERE $sid=:id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt;
    }

    public function checkMobileExists($mobile) {
        $stmt = $this->sb->prepare("SELECT COUNT(*) FROM userlogin WHERE mobile = ?");
        $stmt->execute([$mobile]);
        $count = $stmt->fetchColumn();
        return $count > 0;
    }

    public function checkEmailExists($email)
    {
        $stmt = $this->sb->prepare("SELECT COUNT(*) FROM userlogin WHERE user_emailid = ?");
        $stmt->execute([$email]);
        $count = $stmt->fetchColumn();
        return $count > 0;
    }
    
    public function insert1($mobile, $password, $userfirstname, $userlastname, $userimage, $emailid)
    {
    $stmt = $this->sb->prepare('INSERT INTO userlogin(mobile, password, user_firstname, user_lastname, user_image, user_emailid) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$mobile, $password, $userfirstname, $userlastname, $userimage, $emailid]);
    $user_id = $this->sb->lastInsertId();
    $stmt = $this->sb->prepare('SELECT * FROM userlogin WHERE user_id = ?');
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    return $user_data;
    }
    
    public function insertaddress($country, $state, $city, $pincode, $streetname, $housenumber, $status, $user_id) {
    $stmt = $this->sb->prepare("INSERT INTO address(country, state, city, pincode, streetname, housenumber, status, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$country, $state, $city, $pincode, $streetname, $housenumber, $status, $user_id]);
    $address_id = $this->sb->lastInsertId();
    $stmt = $this->sb->prepare('SELECT * FROM address WHERE address_id = ?');
    $stmt->execute([$address_id]);
    $address_data = $stmt->fetch();
    return $address_data;
    }
    
  public function allselect($t){
   $re=$this->sb->query("select * from $t");
   return $re;
    }
    
    public function deleteaddress($address_id, $user_id){
   $stmt = $this->sb->prepare("DELETE FROM address WHERE address_id = ? AND user_id = ?");
   $stmt->execute([$address_id, $user_id]);
   return $stmt->rowCount();
    }
    public function allselect3($t, $category_id, $subcategory_id, $product_name, $product_price_min, $product_price_max, $brand_id){
   $query = "SELECT * FROM $t WHERE category_id = :category_id AND subcategory_id = :subcategory_id AND product_name LIKE :product_name AND product_price BETWEEN :product_price_min AND :product_price_max AND brand_id = :brand_id";
   $stmt = $this->sb->prepare($query);
   $stmt->bindValue(':category_id', $category_id, PDO::PARAM_INT);
   $stmt->bindValue(':subcategory_id', $subcategory_id, PDO::PARAM_INT);
   $stmt->bindValue(':product_name', "%$product_name%", PDO::PARAM_STR);
   $stmt->bindValue(':product_price_min', $product_price_min, PDO::PARAM_INT);
   $stmt->bindValue(':product_price_max', $product_price_max, PDO::PARAM_INT);
   $stmt->bindValue(':brand_id', $brand_id, PDO::PARAM_INT);
   $stmt->execute();
   return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    function allselect4($t, $i, $n, $s, $e, $su, $b) {
  $stmt = $this->sb->prepare("SELECT * FROM $t WHERE category_id = ? AND subcategory_id = ? OR product_name = ? OR product_price BETWEEN ? AND ? OR brand_id = ?");
  $stmt->execute([$i, $n, $s, $e, $su, $b]);
  return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function count($name) {
  $stmt = $this->sb->prepare("SELECT COUNT(*) FROM $name");
  $stmt->execute();
  return $stmt->fetchColumn();
    }
    
    public function passwordUpdate($pas, $ui, $op) {
  $stmt = $this->sb->prepare("UPDATE userlogin SET password = ? WHERE user_id = ? AND password = ?");
  $stmt->execute([$pas, $ui, $op]);
  return $stmt->rowCount() > 0;
    }
    
    public function selectBanner($bs) {
  $stmt = $this->sb->prepare("SELECT * FROM banner WHERE banner_status = ?");
  $stmt->execute([$bs]);
  return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function insertCartItem($product_id, $quantity, $price, $total_price) {
  $stmt = $this->sb->prepare("INSERT INTO cart (product_id, quantity, price_per_unit, total_price) VALUES (?, ?, ?, ?)");
  $result = $stmt->execute([$product_id, $quantity, $price, $total_price]);
  return $result;
    }
    
    public function updateCartItem($cart_item_id, $quantity, $total_price) {
  $stmt = $this->sb->prepare("UPDATE cart SET quantity = ?, total_price = ? WHERE cart_id = ?");
  $result = $stmt->execute([$quantity, $total_price, $cart_item_id]);
  return $result;
    }
    
    public function getUserByResetCode($reset_code) {
  $stmt = $this->sb->prepare("SELECT user_id FROM userlogin WHERE reset_code = ?");
  $stmt->execute([$reset_code]);
  return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getUserByEmailOrMobile($email_or_mobile) {
  $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE user_emailid = ? OR mobile = ?");
  $stmt->execute([$email_or_mobile, $email_or_mobile]);
  return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function updateUser($mobile, $firstname, $lastname, $email, $user_id) {
  try {
    $stmt = $this->sb->prepare("UPDATE userlogin SET mobile = ?, user_firstname = ?, user_lastname = ?, user_emailid = ? WHERE user_id = ?");
    $stmt->execute([$mobile, $firstname, $lastname, $email, $user_id]);
    return $stmt->rowCount() > 0;
  } catch (PDOException $e) {
    error_log("Error updating user: " . $e->getMessage());
    return false;
  }
    }
    

public function update($mobile, $firstname, $lastname, $email, $user_id) {
  try {
    $stmt = $this->sb->prepare("UPDATE userlogin SET mobile = :mobile, user_firstname = :user_firstname, user_lastname = :user_lastname, user_emailid = :user_emailid WHERE user_id = :user_id");
    $stmt->bindParam(":mobile", $mobile);
    $stmt->bindParam(":user_firstname", $firstname);
    $stmt->bindParam(":user_lastname", $lastname);
    $stmt->bindParam(":user_emailid", $email);
    $stmt->bindParam(":user_id", $user_id);

    $stmt->execute();

    // Fetch updated user data
    $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE user_id = :user_id");
    $stmt->bindParam(":user_id", $user_id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    return $user;
  } catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    return false;
  }
}



  // Function to get cart item details by ID
  public function getCartItem($cart_id) {

    $sql = "SELECT * FROM cart WHERE cart_id = :cart_id";
    $stmt = $this->sb->prepare($sql);
    $stmt->bindParam(':cart_id', $cart_id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
  }

  // Function to update the quantity of an item in the cart
  public function updateCartItemQuantity($cart_id, $quantity) {
    $sql = "UPDATE cart SET quantity = :quantity WHERE cart_id = :cart_id";
    $stmt = $this->sb->prepare($sql);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':cart_id', $cart_id);
    return $stmt->execute();
  }

 public function addCartItem($user_id, $product_id, $quantity) {
    // Check if the item already exists in the cart for the user
    $stmt = $this->sb->prepare("SELECT * FROM cart WHERE user_id=:user_id AND product_id=:product_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':product_id', $product_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // If item exists, update the quantity
    if ($row) {
        $new_quantity = $row['quantity'] + $quantity;
        $stmt = $this->sb->prepare("UPDATE cart SET quantity=:quantity WHERE user_id=:user_id AND product_id=:product_id");
        $stmt->bindParam(':quantity', $new_quantity);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
    } else { // If item does not exist, insert a new row
        $stmt = $this->sb->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->execute();
    }

    // Return the cart item details
    return $this->getCartItem($user_id, $product_id);
}


  // Function to remove an item from the cart
  public function removeCartItem($cart_id) {
    $sql = "DELETE FROM cart WHERE cart_id = :cart_id";
    $stmt = $this->sb->prepare($sql);
    $stmt->bindParam(':cart_id', $cart_id);
    return $stmt->execute();
  }

  // Function to get all cart items for a user
  public function getCartItems($user_id) {
    $sql = "SELECT c.*, p.product_name, p.product_price, p.product_image 
            FROM cart c
            INNER JOIN product p ON c.product_id = p.product_id
            WHERE c.user_id = :user_id";
    $stmt = $this->sb->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

  // Function to empty the cart for a user
  public function emptyCart($user_id) {
    $sql = "DELETE FROM cart WHERE user_id = :user_id";
    $stmt = $this->sb->prepare($sql);
    $stmt->bindParam(':user_id', $user_id);
    return $stmt->execute();
  }
  
     public function getProductById($product_id) {
        $stmt = $this->sb->prepare("SELECT * FROM product_list WHERE product_id = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
      public function getGiftCardByCode($giftCardCode) {
        $stmt = $this->sb->prepare("SELECT * FROM giftcards WHERE giftcard_code = :giftcard_code");
        $stmt->bindParam(':giftcard_code', $giftcard_code, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    
    public function getDiscountCouponById($coupon_id) {
        $stmt = $this->sb->prepare("SELECT * FROM coupon WHERE coupon_id = :coupon_id");
        $stmt->bindParam(':coupon_id', $coupon_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    
    // Function to get subtotal amount for a given bill_id
    public function getSubtotalAmount($bill_id)
    {
        $stmt = $this->sb->prepare("SELECT SUM(product_price * quantity) AS subtotal FROM bill_products WHERE bill_id = :bill_id");
        $stmt->bindParam(':bill_id', $bill_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Function to get coupon discount amount for a given bill_id
    public function getCouponDiscount($bill_id)
    {
        $stmt = $this->sb->prepare("SELECT discount_amount, coupon_name FROM coupons WHERE bill_id = :bill_id");
        $stmt->bindParam(':bill_id', $bill_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Function to get additional fees for a given bill_id
    public function getAdditionalFees($bill_id)
    {
        $stmt = $this->sb->prepare("SELECT af.additionalfee_name, af.additionalfee_amount FROM additional_fee af INNER JOIN bill_additionalfee ba ON af.additionalfee_id = ba.additionalfee_id WHERE ba.bill_id = :bill_id");
        $stmt->bindParam(':bill_id', $bill_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Function to calculate total amount for a given bill_id
    public function getTotalAmount($bill_id)
    {
        $subtotal = $this->getSubtotalAmount($bill_id)['subtotal'];
        $coupon_discount = $this->getCouponDiscount($bill_id)['discount_amount'];
        $additional_fees = $this->getAdditionalFees($bill_id);
        $total = $subtotal;
        foreach ($additional_fees as $additional_fee) {
            $total += $additional_fee['additionalfee_amount'];
        }
        $total -= $coupon_discount;
        return $total;
    }

   
    
  }


?>
