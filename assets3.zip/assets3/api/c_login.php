<?php
require('db.php');
 $data=new db;
 $json = file_get_contents('php://input');
$obj = json_decode($json, TRUE);
  $username=$obj['mobile'];
  $password=$obj['password'];
    $resultant=$data->apiadmin($username,$password);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=$row;
      }
      $returnArr = array("user_list"=>$response,"status"=>true,"ResponseMsg"=>"login  List Founded!");
    }
      else{     
        $returnArr = array("status"=>false,"ResponseMsg"=>"login List Not Founded!");
      }
     
    echo json_encode($returnArr);  
?>