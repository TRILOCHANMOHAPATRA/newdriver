<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='address';
  $sid='user_id';
  $id=$obj['user_id'];
    $resultant=$data->select($table,$sid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=$row;
    }
    $returnArr = array("location_list"=>$response,"status"=>true,"ResponseMsg"=>"location  List Founded!");
  }
    else{     
      $returnArr = array("status"=>false,"ResponseMsg"=>"location List Not Founded!");
    }
   
  echo json_encode($returnArr);   
?>