<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='subcategory';
  $pid='subcategory_name';
  $id=$obj['subcategory_name'];
  
    $resultant=$data->select($table,$pid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=$row;
    }
    $returnArr = array("product_list"=>$response,"status"=>"true","ResponseMsg"=>"product  List Founded!");
  }
    else{     
      $returnArr = array("status"=>"false","ResponseMsg"=>"Category  List Not Founded!");
    }
   
  echo json_encode($returnArr);  
?>