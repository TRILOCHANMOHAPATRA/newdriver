<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// include database connection file
require_once 'db.php';

// get the request parameters from the JSON payload
$params = json_decode(file_get_contents('php://input'), true);

// check if order_id parameter is blank or not an integer
if (empty($params['order_id']) || !is_numeric($params['order_id'])) {
    $response = array('error' => 'order_id parameter is required and must be a valid integer', 'status' => false);
    echo json_encode($response);
    exit;
}

// extract the order_id parameter
$order_id = (int) $params['order_id'];

// connect to the database
$db = new db();
$conn = $db->getConnection();

// Check for connection errors
if (!$conn) {
    $response = array(
        'status' => false,
        'message' => 'Database connection failed: ' . $conn->errorInfo()[2]
    );
    echo json_encode($response);
    exit();
}

// Select the order details from the database
$query = "SELECT * FROM orders WHERE order_id = :order_id";
$stmt = $conn->prepare($query);
$stmt->bindParam(':order_id', $order_id);
$stmt->execute();

// Check if the order details were successfully retrieved from the database
if ($stmt && $stmt->rowCount() > 0) {
    // Fetch the order details
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    // Select the products in the order from the database
    $query = "SELECT product_name, product_id, product_image, discounted_price, quantity, total_price FROM orders WHERE order_id = :order_id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    // Check if the products in the order were successfully retrieved from the database
    if ($stmt && $stmt->rowCount() > 0) {
        // Fetch the products in the order
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Construct the JSON response
        $response = array(
            'status' => true,
            'message' => 'Order details retrieved successfully',
            'order' => $order,
            'products' => $products
        );

        // Send the JSON response
        echo json_encode($response);
    } else {
        // If the products in the order could not be retrieved from the database, return an error response
        $response = array(
            'status' => false,
            'message' => 'Could not retrieve products in order'
        );

        // Send the JSON response
        echo json_encode($response);
    }
} else {
    // If the order details could not be retrieved from the database, return an error response
    $response = array(
        'status' => false,
        'message' => 'Could not retrieve order details'
    );

    // Send the JSON response
    echo json_encode($response);
}

?>