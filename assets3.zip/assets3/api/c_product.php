<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='product_list';
  $pid='category_id';
  $id=$obj['category_id'];
    $resultant=$data->select($table,$pid,$id);
    if($resultant->rowCount()>0){
      while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
        $response[]=$row;
    }
    $returnArr = array("product_list"=>$response,"status"=>"true","ResponseMsg"=>"product  List Founded!");
  }
    else{     
      $returnArr = array("status"=>"false","ResponseMsg"=>"Category  List Not Founded!");
    }
   
  echo json_encode($returnArr);  
?>