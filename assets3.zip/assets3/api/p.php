<!DOCTYPE html>
<html>
<head>
  <title>Email Design</title>
  <style>
    /* Reset some default styles */
    body, table, td, p, a, li {
      -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
      margin: 0;
      padding: 0;
    }

    /* Set a background color and font style for the email */
    body {
      background-color: #f7f7f7;
      font-family: Arial, sans-serif;
    }

    /* Center the email content */
    .container {
      width: 100%;
      max-width: 600px;
      margin: 0 auto;
    }

    /* Add some spacing between elements */
    .spacer {
      height: 20px;
    }

    /* Style the main heading */
    h1 {
      font-size: 24px;
      line-height: 30px;
      color: #333333;
      margin-bottom: 10px;
    }

    /* Style the paragraph text */
    p {
      font-size: 16px;
      line-height: 24px;
      color: #555555;
    }

    /* Style the call-to-action button */
    .cta-button {
      display: inline-block;
      padding: 12px 24px;
      background-color: #0088cc;
      color: #ffffff;
      font-size: 16px;
      text-decoration: none;
      border-radius: 4px;
    }

    /* Style the footer section */
    .footer {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #dddddd;
      font-size: 14px;
      color: #777777;
    }

    /* Style the footer links */
    .footer a {
      color: #777777;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to our Newsletter!</h1>
    <div class="spacer"></div>
    <p>Dear subscriber,</p>
    <p>Thank you for joining our newsletter. Stay up to date with the latest news and updates from our company.</p>
    <div class="spacer"></div>
    <a href="#" class="cta-button">Subscribe</a>
    <div class="spacer"></div>
    <div class="footer">
      <p>For more information, visit our <a href="#">website</a>.</p>
    </div>
  </div>
</body>
</html>
