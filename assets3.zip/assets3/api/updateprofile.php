<?php
require('db.php');
 $data=new db;
 $json = file_get_contents('php://input');
$obj = json_decode($json, TRUE);
  $mobile=$obj['mobile'];
  $password=$obj['password'];
  $firstname=$obj['firstname'];
  $lastname=$obj['lastname'];
  $image=$obj['image'];
  $email=$obj['email'];
  $user_id=$obj['user_id'];
    $resultant=$data->update($mobile,$password,$firstname,$lastname,$image,$email,$user_id);
    if($resultant){
      
      $returnArr = array("status"=>true,"ResponseMsg"=>"update list successfully");
    }
      else{     
        $returnArr = array("status"=>false,"ResponseMsg"=>"not update");
      }
     
    echo json_encode($returnArr);  
?>