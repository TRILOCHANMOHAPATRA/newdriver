<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'mail/Exception.php';
require 'mail/PHPMailer.php';
require 'mail/SMTP.php';
// Load classes and dependencies
$mail = new PHPMailer;
class Mail {
 // Function to send welcome email
public function sendWelcomeEmail($user_email, $user_firstname, $user_lastName, $mobile) {
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host =  'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->Username = 'trilochanmohapatra71846@gmail.com';
    $mail->Password = 'ighdvvsbwuwdnqae';
    $mail->setFrom('trilochanmohapatra71846@gmail.com', 'Trilochan ');
    $mail->addReplyTo('trilochanmohapatra71846@gmail.com', 'trilochan');
    $mail->addAddress($user_email, $user_firstname . ' ' . $user_lastName);
    $mail->isHTML(true);
    $mail->Subject = 'Your Blinkme Grocery account has been created';
    $mail->Body = '
        <html>
        <head>
            <style>
                /* CSS styles here */
                h1 {
                        text-align: center;
                    }
                    .logo {
                        display: block;
                        margin: 0 auto;
                        text-align: center;
                    }
                    .download-link {
                        text-align: center;
                    }
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f1f1f1;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #ffffff;
                        border-radius: 5px;
                        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    }
                    h1 {
                        font-size: 24px;
                        text-align: center;
                    }
                    p {
                        margin-bottom: 20px;
                         text-align: center;
                    }
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        background-color: #007bff;
                        color: #ffffff;
                        text-decoration: none;
                        border-radius: 3px;
                    }
        </style>
    </head>
    <body>
     <div class="logo">
            <img src="https://admin2.blinkme.eu/uploads/logo_email.jpeg">
        </div>
 
        <h1>Welcome to </h1>
                    <p>Dear ' . $user_firstname . ',</p>
                    <p>Thank you for joining us! We are excited to have you on board.</p>
                    <p>Your account has been successfully created with the following details:</p>
                    <ul>
                        <li>Username/Email: ' . $user_email . '</li>
                        <li>Mobile Number: ' . $mobile . '</li>
                    </ul>
                    <p>Start exploring our wide range of products and enjoy a seamless shopping and healthy eating!</p>
                    <p>Explore our mobile application to shop on the go:</p>
                    <p><a class="button" href="[Shop now]">Mobile App</a></p>
                    <p>If you have any questions or need assistance, feel free to reach out to our support team at </p>
                    <p>Happy shopping!</p>
                    <p>Best regards,<br /></p>
                </div>
            </body>
            </html>';
       
    return $mail->send();
}
    
    public function sendOrderConfirmationEmail($user_firstname, $user_emailid, $order_id) {
        $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host =  'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->Username = 'trilochanmohapatra71846@gmail.com';
    $mail->Password = 'ighdvvsbwuwdnqae';
    $mail->setFrom('trilochanmohapatra71846@gmail.com', 'Blinkme ');
    $mail->addReplyTo('trilochanmohapatra71846@gmail.com', 'trilochan');
        $mail->addAddress($user_emailid);
        $mail->addEmbeddedImage('uploads/productimage/coffee.jpg', 'image_cid');
        $mail->isHTML(true);
       $mail->Subject = 'Your Order confirmation on Blinkme Grocery';
    $mail->Body = '
        <html>
        <head>
            <style>
                /* CSS styles here */
                h1 {
                        text-align: center;
                    }
                    .logo {
                        display: block;
                        margin: 0 auto;
                        text-align: center;
                    }
                    .download-link {
                        text-align: center;
                    }
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f1f1f1;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                        background-color: #ffffff;
                        border-radius: 5px;
                        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    }
                    h1 {
                        font-size: 24px;
                        text-align: center;
                    }
                    p {
                        margin-bottom: 20px;
                         text-align: center;
                    }
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        background-color: #007bff;
                        color: #ffffff;
                        text-decoration: none;
                        border-radius: 3px;
                    }
        </style>
    </head>
    <body>
     <div class="logo">
            <img src="https://admin2.blinkme.eu/uploads/logo_email.jpeg">
        </div>
 
        <h1>Thanks for choosing Blinkme Grocery</h1>
                    <p>Dear ' . $user_firstname . ',</p>
                    <p>Thank you for placing an order with Blinkme Grocery! We are happy to receive your order and fullfil your grocery needs!</p>
                    <p> Your order id is
                      <ul>
                        <li>order_id: ' . $order_id . '</li>
                    </ul>
                    <p>Your order has been successfully placed and would be delivery as soon as possible.</p>
                    
                   <p>Please note: All deliveries will be scheduled between 17:00 and 23:00 every day. If you place an order before 17:00, there is a possibility that you will receive it on the same day. Otherwise, your order will be delivered the following day between 17:00 and 23:00.</p>
                    
                    <p>We will keep you posted about your order and update you when it is out for delivery.</p>
                     <p>Enjoy a seamless shopping and healthy eating!</p>
                   
                    <p>If you have any questions or need assistance, feel free to reach out to our support team at support@blinkme.eu.</p>
                    <p>Happy shopping!</p>
                    <p>Best regards,<br />The Blinkme Grocery Team</p>
                </div>
            </body>
            </html>';
       
    return $mail->send();
}
}
?>