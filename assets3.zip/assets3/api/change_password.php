
<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $table='product_list';
  $user_id=$obj['user_id'];
  $newpassword=$obj['newpassword'];
$resultant = $data->paswordupdate($newpassword,$user_id);
if($resultant){
	
  $returnArr = array("status"=>true,"ResponseMsg"=>"password update sucessfully");
}
  else{
	$returnArr = array("status"=>false,"ResponseMsg"=>"update password not sucessfully");
  } 
echo json_encode( $returnArr);   
?>