<?php
if (session_status() == PHP_SESSION_NONE) {
   session_start();
}


define('DBHost', 'mysql:host=localhost;dbname=ra');
define('DBUser', 'root');
define('DBPassword', '');
class db{
 function __construct(){
    $conn=new PDO(DBHost,DBUser,DBPassword);
    $this->sb=$conn;
    
 }
public function apiadmin($user,$pass){
   $result=$this->sb->query("select * from userlogin where mobile='".$user."'  and password='".$pass."'");
   return $result;
}
function select($t,$id,$idd){
   $re=$this->sb->query("select * from $t where $id=$idd");
   return $re;
}

function insert1($m,$p,$uf,$ul,$ui,$ue){
   $re=$this->sb->query("INSERT INTO `userlogin`( `mobile`, `password`, `user_firstname`, `user_lastname`, `user_image`, `user_emailid`)  VALUES ('$m','$p','$uf','$ul','$ui','$ue')");
   return $re;
}
function insertaddress($m,$p,$uf,$ul,$ui,$ue,$user,$u){
   $re=$this->sb->query("INSERT INTO `address`( `country`, `state`, `city`, `pincode`, `streetname`, `housenumber`, `status`, `user_id`) VALUES ('$m','$p','$uf','$ul','$ui','$ue','$user','$u')");
   return $re;
}
function allselect($t){
   $re=$this->sb->query("select * from $t");
   return $re;
}
function deleteaddress($a,$u){
   $re=$this->sb->query("delete from address where address_id='$a' and user_id='$u'");
   return $re;
}
function allselect3($t,$i,$n,$s,$e,$su,$b){
   $re=$this->sb->query("select * from $t where and category_id='$i' and subcategory_id='$n' and product_name like '%$s%' and product_price between '$e' and '$su' and brand_id='$b'");
   return $re;
}
function allselect4($t,$i,$n,$s,$e,$su,$b){
   $re=$this->sb->query("select * from $t where category_id='$i' and subcategory_id='$n' or product_name='$s' or product_price between '$e' and '$su' or brand_id='$b'" );
   return $re;
}
public function count($name){
   $re=$this->sb->query("select count(*) from $name");
   return $re;

}
public function paswordupdate($pas,$ui){
   $re=$this->sb->query("UPDATE `userlogin` SET `password`='$pas' where user_id=$ui ");
   return $re;

}
public function selectbanner($bs){
   $re=$this->sb->query("select * from banner where banner_status=$bs");
   return $re;

}
public function selectfavorite($bs){
   $re=$this->sb->query("select * from favorite where user_id=$bs");
   return $re;

}
public function selectbrand($bs){
   $re=$this->sb->query("select * from brand where user_id=$bs");
   return $re;

}
public function deletecart($t,$c1,$ui,$c2,$pi){
   $re=$this->sb->query("delete from $t where $c1=$ui and $c2=$pi");
   return $re;

}
public function insertcart($ui,$pi,$qt){
   $re=$this->sb->query("INSERT INTO `cart`( `user_id`, `product_id`, `qty`) VALUES ('$ui','$pi','$qt')");
   return $re;

}
public function update($mo,$ps,$uf,$ul,$ui,$ue,$us){
   $re=$this->sb->query("UPDATE `userlogin` SET `mobile`='$mo',`password`='$ps',`user_firstname`='$uf',`user_lastname`='$ul',`user_image`='$ui',`user_emailid`='$ue' WHERE `user_id`='$us'");
   return $re;

}
public function order_listapi($ui,$ci,$bi){
   $re=$this->sb->query("SELECT * FROM order_list WHERE user_id = $ui AND cart_id = $ci AND bill_id = $bi");
   return $re;

}
public function updateorder_listapi($pi,$ps,$os,$oi){
   $re=$this->sb->query("UPDATE order_list SET payment_id = $pi, payment_status = $ps, order_status = $os WHERE order_id = $oi");
   return $re;

}
public function updatecouponapi($pi,$ps,$os,$ci,$oi){
   $re=$this->sb->query("UPDATE order_list SET payment_id = $pi, payment_status = $ps, order_status = $os, coupon_id = $ci WHERE order_id = $oi");
   return $re;

}
public function updatecartapi($id){
   $re=$this->sb->query("UPDATE carts SET status = 3 WHERE cart_id = $id");
   return $re;

}
public function selectorder_listapi($ui,$bi){
   $re=$this->sb->query("SELECT * FROM order_list WHERE user_id = $ui AND bill_id = $bi");
   return $re;

}
public function insertorder_listapi($ui,$ai,$ci,$bi,$pi,$ps,$do,$rb,$cwd,$di,$os){
   $re=$this->sb->query("INSERT INTO order_list (user_id, address_id, cart_id, bill_id, payment_id, payment_status, drop_outside, ring_bell, call_while_delivery, delivery_instructions, order_status) VALUES ('$ui','$ai','$ci','$bi','$pi','$ps','$do','$rb','$cwd','$di','$os')");
   return $re;

}
public function updatecoupon($ci){
   $re=$this->sb->query("UPDATE coupon_usage SET usage_count = 1 WHERE coupon_id = $ci");
   return $re;

}
public function getcart($bi){
   $re=$this->sb->query("SELECT cart_id FROM bill WHERE bill_id = $bi");
   return $re;

}
public function checkMobileExists($mobile) {
   $stmt = $this->sb->prepare("SELECT COUNT(*) FROM userlogin WHERE mobile = ?");
   $stmt->execute([$mobile]);
   $count = $stmt->fetchColumn();
   return $count > 0;
}

public function checkEmailExists($email)
    {
        $stmt = $this->sb->prepare("SELECT COUNT(*) FROM userlogin WHERE user_emailid = ?");
        $stmt->execute([$email]);
        $count = $stmt->fetchColumn();
        return $count > 0;
    }
 public function getUserByEmailOrMobile($email_or_mobile) {
      $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE user_emailid = ? OR mobile = ?");
      $stmt->execute([$email_or_mobile, $email_or_mobile]);
      return $stmt->fetch(PDO::FETCH_ASSOC);
        }
 public function getUserDataByMobile($mobile)
    {
        $stmt = $this->sb->prepare("SELECT * FROM userlogin WHERE mobile = :mobile LIMIT 1");
        $stmt->bindParam(':mobile', $mobile, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>