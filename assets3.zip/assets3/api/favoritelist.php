<?php
require('db.php');
  $data=new db;
  $json = file_get_contents('php://input');
  $obj = json_decode($json, TRUE);
  $user_id=$obj['user_id'];
  $resultant=$data->selectfavorite($user_id);
  if($resultant->rowCount()>0){
    while($row=$resultant->fetch(PDO::FETCH_ASSOC)){
      $response[]=$row;
    }
    $returnArr = array("favorite_list"=>$response,"status"=>true,"ResponseMsg"=>"favorite  List Founded!");
  }
    else{     
      $returnArr = array("status"=>false,"ResponseMsg"=>"favorite List Not Founded!");
    }
  echo json_encode($returnArr); 
?>