
<?php 

require ('layouts/header.php');
?>
<!DOCTYPE html>
<!-- saved from url=(0036)https://www.servecircle.com/reports/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
                <title>Reports</title>
                <meta name="_csrf" content="05320c6a-c351-4cb9-b574-6aa9333b7ac0">
                <meta name="_csrf_header" content="X-CSRF-TOKEN">
                <meta name="viewport" content="width=device-width, initial-scale=1">
               
                
                <link rel="stylesheet" type="text/css" href="bootstrap.min-4.css">
                
                <link rel="stylesheet" type="text/css" href="main.css">
            </head>

            <body>
                <div class="custom-modal-bg error-modal" id="errorModal">
    <div class="centered custom-modal-wrpr">
        <div class="custom-modal-hdr">
            <h2>Error</h2>
            <i class="fas fa-times"></i>
        </div>
        <div class="custom-modal-body bg-white">
            <div class="error-msg" id="errorModalMsg">Something went wrong. Please try again.</div>
        </div>
        <div class="custom-modal-footer">
            <input id="closeErrorModal" class="white-button" type="button" value="Ok">
        </div>
    </div>
</div>
                    <div class="wrapper clearfix">
                        
    
    <div id="topLoader" class="top-loader"></div>
    
<div class="greeting-wrpr">
    <i class="fas fa-gift"></i> Introducing Advanced and Enterprise packages with lot more features to manage your business.
    
</div>
                                    <div class="banner">
                                        <div class="banner-section-cntr">
                                            <div class="row">
                                                <div class="col-xs-12 col-md-12">
                                                    <div class="banner-hdg clearfix">
                                                        <h1>
                                                            Reports
                                                        </h1>
                                                    </div>
                                                    <p>
                                                        <span class="document-quote-text">Day to day insights of your growing business.</span>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Banner End -->
                                    <div class="report-page">
                                        <div class="report-search-wrpr bg-white">
                                            <h3>Show Report For</h3>
                                            <ul class="row report-search-items">
                                                <li class="col-lg-3 col-md-4 col-sm-12 position-relative">
                                                    <label>Branch</label>
                                                    <select id="storesDrpDown">
                                                        <option value="all">All Branches</option>
                                                    <option value="6671">any</option><option value="6673">trilochan mohapatra</option></select>
                                                </li>
                                                <li class="col-lg-3 col-md-4 col-sm-12 position-relative">
                                                    <label>License Type</label>
                                                    <select id="licenseTypeDrpDown">
                                                        <option value="ALL">All</option>
                                                        <option value="SERVICE">Service</option>
                                                        <option value="SALESANDBILLING">Sales and Billing</option>
                                                    </select>
                                                </li>
                                                <li class="col-lg-3 col-md-4 col-sm-12 position-relative">
                                                    <label>Transaction Period From<span class="mandatory-field">*</span></label>
                                                    <input id="reportsFrom" type="text" class="hasDatepicker">
                                                    <i class="fas fa-calendar-alt"></i>
                                                    <span class="form-list-input-error"></span>
                                                </li>
                                                <li class="col-lg-3 col-md-4 col-sm-12 position-relative">
                                                    <label>Transaction Period To<span class="mandatory-field">*</span></label>
                                                    <input id="reportsTo" type="text" class="hasDatepicker">
                                                    <i class="fas fa-calendar-alt"></i>
                                                    <span class="form-list-input-error"></span>
                                                </li>
                                            </ul>
                                            <div class="report-center-btn-wrpr">
                                                <input type="button" name="submit" value="Submit" class="job-search-btn" id="searchSubmitBtn">
                                                <button title="gstSubmit" id="gstSubmitBtn" class="job-search-btn">
                                                    <i class="fas fa-download"></i> Download GST Report
                                                </button>
                                            </div>
                                        </div>
                                        <div class="report-search-dtls">
                                            <h3 class="report-search-dtls-hdg">Report from <span id="generatedReportFrom">1-Aug-2023</span> to <span id="generatedReportTo">25-Aug-2023</span> for <span id="selectedStore">All Branches</span></h3>
                                            <div id="reportCntr" class="report-cntr clearfix">
                                                <div class="float-left jobsheet-report-dtls-wrpr">
                                                    <div class="report-space-wrpr" id="serviceData">
                                                        <h4>Job Sheets <span>(On Created Date)</span></h4>
                                                        <div class="jobsheet-report-dtls bg-white pb-0">
                                                            <ul class="row reports-list">
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="totalJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Total Job sheets</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="requestedJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Requested</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="assignedJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Assigned</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="pickedUpJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Picked Up</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="openJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Open</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="initialCheckJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Initial Check</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="pendingJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Pending</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="rwrJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Return Without Repair</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="closedJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Closed</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="preInvoiceJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Pre-Invoice</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="outForDeliverJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Out For Delivery</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="pendingPaymentJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Pending Payment</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="serviceSentJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Sent Out For Service</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="deliveredJobSheets">0</div>
                                                                    <div class="reports-list-label text-center">Delivered</div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="report-space-wrpr" id="billsData">
                                                        <h4>Sales</h4>
                                                        <div class="jobsheet-report-dtls bg-white pb-0">
                                                            <ul class="row reports-list">
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="totalBills">0</div>
                                                                    <div class="reports-list-label text-center">Total Bills</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="paymentPendingBills">0</div>
                                                                    <div class="reports-list-label text-center">Payment Pending</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="paidBills">0</div>
                                                                    <div class="reports-list-label text-center">Paid</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="cancelledBills">0</div>
                                                                    <div class="reports-list-label text-center">Cancelled</div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="report-space-wrpr">
                                                        <h4>Accounts(Rs.) <span>(On Billing Date)</span></h4>
                                                        <div class="account-report-dtls bg-white pb-0">
                                                            <ul class="row reports-list">
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="serviceCharge">0</div>
                                                                    <div class="reports-list-label text-center">Service Charge</div>
                                                                </li>
                                                                <!-- <li class='col-sm-6 col-lg-2 col-md-2'>
                                                                    <div class="reports-list-val text-center" id='serviceTax'></div>
                                                                    <div class="reports-list-label text-center">service tax</div>
                                                                </li>
                                                                <li class='col-sm-6 col-lg-2 col-md-2'>
                                                                    <div class="reports-list-val text-center" id='swachhBharatCess'></div>
                                                                    <div class="reports-list-label text-center">swachh bharat cess</div>
                                                                </li>
                                                                <li class='col-sm-6 col-lg-2 col-md-2'>
                                                                    <div class="reports-list-val text-center" id='krishiKalyanCess'></div>
                                                                    <div class="reports-list-label text-center">krishi kalyan cess</div>
                                                                </li> -->
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="grassComponentCharge">0</div>
                                                                    <div class="reports-list-label text-center">Gross component charge</div>
                                                                </li>
                                                                <!-- <li class='col-sm-6 col-lg-2 col-md-2'>
                                                                    <div class="reports-list-val text-center" id='totalVat'></div>
                                                                     <div class="reports-list-label text-center">VAT</div>
                                                                </li> -->
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="totalAmount">0</div>
                                                                    <div class="reports-list-label text-center">Total Amount</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-2 col-md-2">
                                                                    <div class="reports-list-val text-center" id="totalNoOfBills">0</div>
                                                                    <div class="reports-list-label text-center">Total No. of bills</div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="job-lists-table-wrpr bg-white" style="display: none;">
                                                        <h4>Services: Tax Reports</h4>
                                                        <div class="position-relative table-responsive">
                                                            <table class="job-lists-table table">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="header">Unique Identifier</th>
                                                                        <th class="header">Tax from Services(Rs.)</th>
                                                                        <th class="header">Tax from Components(Rs.)</th>
                                                                        <th class="header">Total(Rs.)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="serviceTaxReport"></tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <div class="job-lists-table-wrpr bg-white" style="display: none;">
                                                        <h4>Simple Bill: Tax Reports</h4>
                                                        <div class="position-relative table-responsive">
                                                            <table class="job-lists-table table">
                                                                <thead>
                                                                    <tr>
                                                                        <th class="header">Unique Identifier</th>
                                                                        <th class="header">Service Tax Amount(Rs.)</th>
                                                                        <th class="header">Components Tax Amount(Rs.)</th>
                                                                        <th class="header">Total(Rs.)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="simpleBillReport"></tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <!-- <div class="float-left account-report-dtls-wrpr amount-collected-wrpr">
									<h4>Amount Collected(Rs.)</h4>
									<div class="account-report-dtls">
										<ul class="reports-list">
											<li>
												<div class="reports-list-val text-center"><span id='totalAmountCollected'></span> ( <span id='advanceAmountCollected'></span> + <span id='billingAmountCollected'></span> )</div>
												<div class="reports-list-label text-center">Total ( Advance + Billing )</div>
											</li>
										</ul>
									</div>
								</div> -->
                                                    <div class="account-report-dtls-wrpr amount-collected-wrpr mt-3">
                                                        <h4>Amount Collected(Rs.)</h4>
                                                        <div class="account-report-dtls bg-white pb-0">
                                                            <ul class="row reports-list">
                                                                <li class="col-sm-6 col-lg-3 col-md-3">
                                                                    <div class="reports-list-val text-center"><span id="totalAmountCollected">0</span> ( <span id="advanceAmountCollected">0</span> + <span id="billingAmountCollected">0</span> )</div>
                                                                    <div class="reports-list-label text-center">Services: Total ( Advance + Billing )</div>
                                                                </li>
                                                                <li class="col-sm-6 col-lg-3 col-md-3">
                                                                    <div class="reports-list-val text-center"><span id="simplebillTotalAmountCollected">0</span> ( <span id="simplebillAdvanceAmountCollected">0</span> + <span id="simplebillBillingAmountCollected">0</span> )</div>
                                                                    <div class="reports-list-label text-center">Simple Bill: Total ( Advance + Billing )</div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!-- <div class="mt-3">
                                                        <h4>Inventory Reports</h4>
                                                        <div class="jobsheet-report-dtls bg-white pb-0">
                                                            <ul class="row reports-list">
                                                                <li class='col-sm-6 col-lg-2 col-md-2'>
                                                                    <div class="reports-list-val text-center">Rs.<span id="totalStockValue" ></span></div>
                                                                    <div class="reports-list-label text-center">Total Stock Value</div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div> -->
                                                </div>
                                                <div class="float-left graph-cntr sales-graph">
                                                    <div id="serviceChartCntr"><canvas id="serviceChart" height="300"></canvas></div>
                                                </div>
                                                <div class="float-left graph-cntr sales-graph">
                                                    <div id="salesChartCntr"><canvas id="salesChart" height="300"></canvas></div>
                                                </div>
                                            </div>
                                            <div id="noDataCntr" class="no-data-cntr text-center" style="display: none;">
                                                <i class="fas fa-chart-pie"></i>
                                                <div class="no-data-desc">No Data in the selected time period.</div>
                                            </div>
                                            <div id="dataNotLoaded" class="no-data-cntr text-center" style="display: none;">
                                                <i class="fas fa-chart-pie"></i>
                                                <div class="no-data-desc">Couldn't load report. Please try again.</div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                    </div>
                    <div class="store-popup-bg" id="loaderBg" style="display: none;">
    <img class="loader" alt="loading" src="./Reports_files/loader.gif">
</div>
                        <!--Start of Zendesk Chat Script-->
<script type="text/javascript" async="" src="./Reports_files/js"></script><script async="" src="./Reports_files/analytics.js.download"></script><script type="text/javascript">
/*     window.$zopim || (function(d, s) {
        var z = $zopim = function(c) {
                z._.push(c)
            },
            $ = z.s =
            d.createElement(s),
            e = d.getElementsByTagName(s)[0];
        z.set = function(o) {
            z.set.
            _.push(o)
        };
        z._ = [];
        z.set._ = [];
        $.async = !0;
        $.setAttribute("charset", "utf-8");
        $.src = "https://v2.zopim.com/?5UBtRGdnRYVuAYzwzDwgt8vqXEDt9BBJ";
        z.t = +new Date;
        $.
        type = "text/javascript";
        e.parentNode.insertBefore($, e)
    })(document, "script"); */

            

            <iframe allow="join-ad-interest-group" data-tagging-id="AW-970053180" data-load-time="1692957532950" height="0" width="0" style="display: none; visibility: hidden;" src="./Reports_files/970053180.html"></iframe><script type="text/javascript" async="" src="./Reports_files/f.txt"></script><div id="ui-datepicker-div" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div></body></html>