`<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  
  $name=$_POST['name'];
  $datatype=$_POST['datatype'];
  $value=$_POST['value'];
  
   if(empty($errors)){
     $re=$data-> addclaim($name,$datatype,$value);
      if($re){
       header('location:claimtype.php');
      } else {
        header('location:add_claimtype.php');
      }
   } 
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New claimtype</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_claimtype.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Name</label>
                <input type="text" class="form-control" name="name" placeholder="Name">
            </div>
            <div class="form-group">
            <label >claim data types</label>
                <input type="text" class="form-control" name="datatype" placeholder="Claim Data Types">
            </div>
            <div class="form-group">
            <label >Values</label>
                <input type="number" class="form-control" name="value" placeholder="Values">
</div>
            <button type="submit" name="add_cat" class="btn btn-primary">Add new claimtype</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  
