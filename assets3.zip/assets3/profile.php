<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='product';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
         
          
       </strong>
       <a href="profile.php" class="btn btn-info pull-left">logo</a>
       <a href="accountdetels.php" class="btn btn-info pull-left">Account detels</a>
       <a href="products.php" class="btn btn-info pull-left">product</a>
       <a href="smssender.php" class="btn btn-info pull-left">SMS Sender Id</a>
       <a href="terms.php" class="btn btn-info pull-left">terms and condition</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
        <div class="form-group">
                            <label for="upload">Image Main:</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="main" name="main" accept="image/*">
                                <label class="custom-file-label" for="upload">Select file</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="image-preview">
                                <img id="preview-main" src="" alt="Preview" style="float:right; max-width: 700px; max-height: 500px;">
                            </div>
                        </div>
        <tbody>
        
          <tr>
          
          </tr>
        <?php ?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
<script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview-main').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#main").change(function() {
                readURL(this);
            });
        });
    </script>

 
