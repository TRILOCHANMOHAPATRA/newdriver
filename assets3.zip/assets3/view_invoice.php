<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?>


<?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $page='';
  $data=new db;
  if(isset($_GET['id'])){
    $id=$_GET['id'];
  }
 $jobsheet=$data->invoice($id);
  require_once('includes/load.php'); 
?>
<?php
if (!isset ($_GET['page']) ) {  
    $page = 1;  
} else {  
    $page = $_GET['page'];  
}  
?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>invoice</span>  
       </strong>
       <a href="add_invoice.php" class="btn btn-info pull-right">add invoice</a>
      </div>
    <?php while($row=$jobsheet->fetch(PDO::FETCH_ASSOC)){ ?>
     <div class="panel-body">
     <div class="card text-bg-dark">
  
  <div class="card-img-overlay">
    <h5 class="card-title">jobsheet_number:<?php echo $row['jobsheet_number'];?></h5>
    <h5 class="card-title">name=<?php echo $row['firstname'] .$row['lastname'];?></h5>
    <h5 class="card-title">mobile number=<?php echo $row['mobile_number'];?></h5>
    <h5 class="card-title">alternatemobile number=<?php echo $row['alternate_mobile'];?></h5>
    <h5 class="card-title">email=<?php echo $row['email_id'];?></h5>
    <h5 class="card-title">address=<?php echo $row['address'];?></h5>
    <h5 class="card-title">GSTIN=<?php echo $row['gstin'];?></h5>
    <h5 class="card-title">product type=<?php echo $row['product_type'];?></h5>
    <h5 class="card-title">brand=<?php echo $row['brand'];?></h5>
    <h5 class="card-title">mobile name=<?php echo $row['model_name'];?></h5>
    <h5 class="card-title">mobile number=<?php echo $row['modelno'];?></h5>
    <h5 class="card-title">color=<?php echo $row['color'];?></h5>
    <h5 class="card-title">configuration=<?php echo $row['configuration'];?></h5>
    <h5 class="card-title">SINO=<?php echo $row['sino'];?></h5>
    <h5 class="card-title">SINO2=<?php echo $row['sino2'];?></h5>
    <h5 class="card-title">status=<?php echo $row['status'];?></h5>
    <h5 class="card-title">Problem=<?php echo $row['problem'];?></h5>
    <h5 class="card-title">Cost=<?php echo $row['cost'];?></h5>
    <h5 class="card-title">Advance=<?php echo $row['advance'];?></h5>
    <h5 class="card-title">delivery date=<?php echo $row['delivery_date'];?></h5>
    <h5 class="card-title">delivery time=<?php echo $row['delivery_time'];?></h5>
    <h5 class="card-title">condition=<?php echo $row['condition'];?></h5>
   
  </div>
</div>
<?php } ?>
     
    </div>
  </div>
 
</div>
<?php include_once('layouts/footer.php'); ?>
