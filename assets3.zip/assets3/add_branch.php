<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['add_cat'])){
  $table='branch';
  $name=$_POST['name'];
  $address=$_POST['address'];
  $city=$_POST['City'];
  $contract=$_POST['contract'];
  $additional=$_POST['additional'];
  $email=$_POST['email'];
   if(empty($errors)){
     $re=$data-> insertbrach($name,$address,$city,$contract,$additional,$email);
      if($re){
       header('location:branch.php');
      } else {
        header('location:add_branch.php');
      }
   } else {
    header('location:banner.php');
   }
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New branch</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="add_branch.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Name</label>
                <input type="text" class="form-control" name="name" placeholder="Name">
            </div>
            <div class="form-group">
            <label >address</label>
                <input type="text" class="form-control" name="address" placeholder="address">
            </div>
            <div class="form-group">
            <label >city</label>
                <input type="text" class="form-control" name="City" placeholder="City">
            </div>
            <div class="form-group">
            <label >contract no</label>
                <input type="number" class="form-control" name="contract" placeholder="contract">
            </div>
            <div class="form-group">
            <label >additional no</label>
                <input type="number" class="form-control" name="additional" placeholder="Additional">
            </div>
            <div class="form-group">
            <label >email id</label>
                <input type="text" class="form-control" name="email" placeholder="Email">
            </div>
            
            <button type="submit" name="add_cat" class="btn btn-primary">Add new branch</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  <script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#admin").change(function() {
                readURL(this);
            });
        });
    </script>
