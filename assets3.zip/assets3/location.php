<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
  require('includes/dbconfig.php');
  $data=new db;
  $name='address';
  $location=$data->select($name);
  
  require_once('includes/load.php'); 
?>
<?php include_once('layouts/header.php'); ?>
  <div class="row">
     <div class="col-md-12">
     </div>
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>locations</span>
       </strong>
         <a href="add_location.php" class="btn btn-info pull-right">Add New location</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="text-center" style="width: 50px;">#</th>
            <th>Country </th>
            <th>State</th>
            <th class="text-center" style="width: 15%;">City</th>
            <th class="text-center" style="width: 15%;">Pincode</th>
            <th class="text-center" style="width: 15%;">Streetname</th>
            <th class="text-center" style="width: 15%;">Housenumber</th>
            <th style="width: 20%;">status</th>
            <th class="text-center" style="width: 100px;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php while($row=$location->fetch(PDO::FETCH_ASSOC)){ ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><?php echo remove_junk(ucwords($row['country']))?></td>
           <td><?php echo remove_junk(ucwords($row['state']))?></td>
           <td><?php echo remove_junk(ucwords($row['city']))?></td>
           <td><?php echo remove_junk(ucwords($row['pincode']))?></td>
           <td><?php echo remove_junk(ucwords($row['streetname']))?></td>
           <td><?php echo remove_junk(ucwords($row['housenumber']))?></td>
           <td class="text-center">
           <?php 
                    if($row['primary_address_status']=="1") {
                        echo 
"<a href=lactive.php?id=".$row['address_id']." class='btn btn-success'>Activate</a>";
                    }
                    else {
                        echo 
"<a href=ldeactive.php?id=".$row['address_id']." class='btn btn-danger'>Dectivate</a>";
                     } ?>
           </td>
           
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_location.php?id=<?php echo $row['address_id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="glyphicon glyphicon-pencil"></i>
               </a>
                <a href="delete_location.php?id=<?php echo $row['address_id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="glyphicon glyphicon-remove"></i>
                </a>
                </div>
           </td>
          </tr>
        <?php }?>
       </tbody>
     </table>
    
    
     </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

