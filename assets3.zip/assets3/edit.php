<?php
if(isset($_GET['id'])){
    $idd=$_GET['id']; 
  }
  echo $idd;
  ?>