<?php
define('DBHost', 'mysql:host=localhost;dbname=ra');
define('DBUser', 'root');
define('DBPassword', '');
class db{
   function __construct(){
      $conn=new PDO(DBHost,DBUser,DBPassword);
      $this->sb=$conn;
   }
   public function inset($name,$design,$department){
     $re=$this->sb->query("INSERT INTO `employee`( `name`, `design`, `department`) VALUES ('$name','$design','$department')");
     return $re;
  
  }
  public function insetproduct($catid,$pname,$des,$imp,$price,$img,$sta,$subcatid,$un,$vol,$ps,$br){
     $re=$this->sb->query("INSERT INTO `product_list`( `category_id`, `product_name`, `product_description`,`important information`, `product_price`, `product_image`, `product_status`, `subcategory_id`, `unit_id`,`Volume`,`product_source`, `brand_id`) VALUES  ('$catid','$pname','$des','$imp','$price','$img','$sta','$subcatid','$un','$vol','$ps','$br')");
     return $re;
  
  }
  public function editproduct($catid,$pname,$pd,$ii,$pp,$d,$pi,$si,$ui,$bi,$v,$ps,$pso,$id){
   $re=$this->sb->query("UPDATE `product_list` SET `category_id`='$catid',`product_name`='$pname',`product_description`='$pd',`important information`='$ii',`product_price`='$pp',`discount`='$d',`product_image`='$pi',`subcategory_id`='$si',`unit_id`='$ui',`brand_id`='$bi',`Volume`='$v',`product_status`='$ps',`product_source`='$pso' WHERE`product_id`='$id'");
   return $re;

}
  public function apiadmin($user,$pass){
     $result=$this->sb->query("select * from apilogin where username='".$user."'  and password='".$pass."'");
     return $result;
  }
  
  public function uinsert($username,$password){
     $res=$this->sb->query("INSERT INTO `users` ( `username`, `password`) VALUES ('$username', '$password')");
     return $res;
  }
  public function catlist($cat,$img,$dis){
     $res=$this->sb->query("INSERT INTO `category_list`( `category_name`, `category_image`, `category_description`) VALUES ('$cat','$img','$dis')");
     return $res;
  }
  public function login($username,$password){
     $result=$this->sb->query("Select * from users where username='$username' AND password='$password'");
     return $result;
  }
  
  public function apiadminstatus(){
     $result=$this->sb->query("select * from admin where status = 1");
     return $result;
  }
  public function signup($username){
     $result=$this->sb->query("SELECT * FROM `users` WHERE username = '$username'");
     return $result;
  }
  
  public function select($c){
     $re=$this->sb->query("select * from $c");
     return $re;
  
  }
  public function select2($c){
   $re=$this->sb->query("select * from $c");
   return $re;

}
 
  public function selectdatewise($name){
   $re=$this->sb->query("select * from $name order by order_date desc");
   return $re;

}
  public function selectu2($t,$i,$id){
     $re=$this->sb->query("select * from $t where $i='$id' order by order_date desc");
     return $re;
  
  }
  public function selectu($t,$i,$id){
   $re=$this->sb->query("select * from $t where $i='$id'");
   return $re;

}

  public function couponid($id){
     $re=$this->sb->query("select * from costumber where id=$id");
     return $re;
  }
  public function couponid2($id){
   $re=$this->sb->query("select * from jobsheet where id=$id");
   return $re;

}
  public function unit($name){
     $re=$this->sb->query("select * from unit where unit_id='$name'");
     return $re;
  
  }
  public function brandname($name){
     $re=$this->sb->query("select * from brand where brand_id='$name'");
     return $re;
  
  }
  public function productname($name){
     $re=$this->sb->query("select * from product_list where product_id='$name'");
     return $re;
  
  }
  public function wselect($idd){
     $re=$this->sb->query("select * from subcategory where category_id='$idd'");
     return $re;
  
  }
  public function count($name){
     $re=$this->sb->query("select count(*) from $name");
     return $re;
  
  }
  function selectproducttype($d){
   $re=$this->sb->query("select * from product_type where brand_id='$d'");
   return $re;
  }
  public function invoice($i){
   $re=$this->sb->query("select * from jobsheet where id='$i' ");
   return $re;
  }
  function jobsheetdatewise($l1,$l2){
   $re=$this->sb->query("SELECT * FROM jobsheet
   WHERE delivery_date BETWEEN '$l1' AND '$l2'");
   return $re;

  }
  public function countpending($name,$c,$st){
     $re=$this->sb->query("select count(*) from $name where $c=$st");
     return $re;
  
  }
  public function countdelivery($t,$c,$d){
     $re=$this->sb->query("select count(*) from $t where $c='$d'");
     return $re;
  
  }
  public function partner1($id){
     $re=$this->sb->query("select * from partner where id=".$id."");
     return $re;
  }
  public function orderid($id){
     $re=$this->sb->query("select * from orders where order_id=".$id."");
     return $re;
  }
  public function wselect2($t,$id,$idd){
     $re=$this->sb->query("select * from $t where $id=".$idd."");
     return $re;
  }
  
  public function selectuser($id){
     $re=$this->sb->query("select * from userlogin where user_id=$id");
     return $re;
  }
  public function selectuserproduct($id){
     $re=$this->sb->query("select * from product_list where product_id=$id");
     return $re;
  }
  public function selectbrand($id){
     $re=$this->sb->query("select * from brand where brand_id=$id");
     return $re;
  }
  public function categoryname($id){
     $re=$this->sb->query("select * from category_list where category_id=$id");
     return $re;
  }
  
  public function Deletedata1($table,$ci,$id){
     $re=$this->sb->query("delete from $table where $ci=$id");
     return $re;
  
  }
  public function insertcategory($cname,$cimage,$cdes,$st){
     $re=$this->sb->query("INSERT INTO `category_list`( `category_name`, `category_image`, `category_description`, `cat_status`)VALUES ('$cname','$cimage','$cdes','$st')");
     return $re;
  
  }
  public function insertsubcategory($sname,$sdes,$cid,$simage ){
     $re=$this->sb->query("INSERT INTO `subcategory`( `subcategory_name`, `subcategory_description`, `category_id`, `subcategory_image`) VALUES ('$sname','$sdes','$cid','$simage')");
     return $re;
  
  }
  public function editsubcategory($sname,$sdes,$cid,$simage,$id ){
     $re=$this->sb->query("UPDATE `subcategory` SET `subcategory_name`='$sname',`subcategory_description`='$sdes',`category_id`='$cid',`subcategory_image`='$simage' WHERE `subcategory_id`='$id'");
     return $re;
  
  }
  public function insertlocation($con,$sta,$cit,$p,$st,$ho,$stat){
     $re=$this->sb->query("INSERT INTO `address`( `country`, `state`, `city`, `pincode`, `streetname`, `housenumber`, `status`) VALUES ('$con','$sta','$cit','$p','$st','$ho','$stat')");
     return $re;
  
  }
  public function editlocation($con,$sta,$cit,$p,$st,$ho,$stat,$id){
     $re=$this->sb->query("UPDATE `address` SET `country`='$con',`state`='$sta',`city`='$cit',`pincode`='$p',`streetname`='$st',`housenumber`='$ho',`status`='$stat' WHERE `address_id`='$id'");
     return $re;
  
  }
  public function getcatname($catd){
     $re=$this->sb->query("select * from category_list where category_id='$catd'");
     return $re;
  
  }
  public function banner($bn,$bi,$bv,$bd,$bs,$po){
     $re=$this->sb->query("INSERT INTO `banner`( `banner_name`, `banner_image`, `banner_video`, `banner_date`, `banner_status`, `banner_position`) VALUES ('$bn','$bi','$bv','$bd','$bs','$po')");
     return $re;
  
  }
  public function selectbanner($id){
   $re=$this->sb->query("select * from banner where banner_id=$id");
   return $re;

}
public function service($i){
   $r=$this->sb->query("select * from service where id='$i'");
   return $r;
}
  function updatestatus($t,$c,$ps,$wc,$pi){
     $r=$this->sb->query("update $t set $c=$ps where $wc=$pi");
     return $r;
  }
  public function insertproductimage($pi,$if,$it,$is,$ib,$in,$iv,$iu,$im,$ist){
     $re=$this->sb->query("INSERT INTO `product_images`( `product_id`, `image_front`, `image_top`, `image_side`, `image_back`, `image_nutrition`, `image_video`, `image_using`, `image_misc`, `image_status`) VALUES ('$pi','$if','$it','$is','$ib','$in','$iv','$iu','$im','$ist')");
     return $re;
  
  }
  public function editproductimage($pi,$if,$it,$is,$ib,$in,$iv,$iu,$im,$ist,$id){
     $re=$this->sb->query("UPDATE `product_images` SET `product_id`='$pi',`image_front`='$if',`image_top`='$it',`image_side`='$is',`image_back`='$ib',`image_nutrition`='$in',`image_video`='$iv',`image_using`='$iu',`image_misc`='$im',`image_status`='$ist' WHERE`product_id`='$id'");
     return $re;
  
  }
  public function insertshopforme($pm,$q,$u,$s,$ui){
     $re=$this->sb->query("INSERT INTO `shop_for_me`( `product_name`, `quantity`, `unit`, `store`, `user_id`) VALUES ('$pm','$q','$u','$s','$ui')");
     return $re;
  
  }
  public function authenticate($username,$password){
     $re=$this->sb->query("SELECT * FROM admin WHERE username ='$username' and password='$password'");
     return $re;
  }
  
  public function editcategory($catn,$cati,$catd,$cats,$id){
     $re=$this->sb->query("UPDATE `category_list` SET `category_name`='$catn',`category_image`='$cati',`category_description`='$catd',`cat_status`='$cats' WHERE `category_id`='$id'");
     return $re;
  
  }
  public function editbanner($bi,$bv,$bd,$bs,$po,$id){
     $re=$this->sb->query("UPDATE `banner` SET `banner_image`='$bi',`banner_video`='$bv',`banner_date`='$bd',`banner_status`='$bs',`banner_position`='$po' WHERE `banner_id`='$id'");
     return $re;
  
  }
  public function insertcoupon($cc,$dt,$da,$ced,$cs,$mu,$sd,$ld,$ii,$ti){
     $re=$this->sb->query("INSERT INTO `coupon`( `coupon_code`, `discount_type`, `discount_amount`, `coupon_expiry_date`, `coupon_status`, `multiple_usage`, `short_description`, `long_description`, `icon_image`, `title`) VALUES ('$cc','$dt','$da','$ced','$cs','$mu','$sd','$ld','$ii','$ti')");
     return $re;
  
  }
  public function editcoupon($cc,$dt,$da,$ced,$cs,$mu,$sd,$ld,$ii,$ti,$id){
     $re=$this->sb->query("UPDATE `coupon` SET `coupon_code`='$cc',`discount_type`='$dt',`discount_amount`='$da',`coupon_expiry_date`='$ced',`coupon_status`='$cs',`multiple_usage`='$mu', `short_description`='$sd',`long_description`='$ld',`icon_image`='$ii',`title`='$ti' WHERE `coupon_id`='$id'");
     return $re;
  
  }
  function editusers($mo,$uf,$ul,$ue,$id){
     $re=$this->sb->query("UPDATE `userlogin` SET `mobile`='$mo',`user_firstname`='$uf',`user_lastname`='$ul',`user_emailid`='$ue' WHERE `user_id`='$id'");
     return $re;
  }
  //additional fee inset 
  public function insertadditionalfee($an,$aa,$ma,$at,$as,$pi,$ci,$si){
     $re=$this->sb->query("INSERT INTO `additional_fee`( `additionalfee_name`, `additionalfee_amount`, `min_amount`, `additionalfee_type`, `additionalfee_status`, `product_id`, `category_id`, `subcategory_id`) VALUES ('$an','$aa','$ma','$at','$as','$pi','$ci','$si')");
     return $re;
  }
  function chosesubcategory($id){
     $re=$this->sb->query("select * from subcategory where category_id=$id");
     return $re;
  }
  function cashondelivery($id){
     $re=$this->sb->query("select * from orders where payment_mode='$id'");
     return $re;
  }
  function countstatus($id){
     $re=$this->sb->query("select count(*) from orders where status='$id'");
     return $re;
  }
  function productlimit($li,$lii){
     $re=$this->sb->query("select * from product_list limit $li,$lii");
     return $re;
  }
  function insertpimage($pt,$m,$mi,$f,$fi,$t,$ti,$s,$si,$n,$ni,$u,$ui,$mic,$mici,$ss){
     $re=$this->sb->query("INSERT INTO `product_images`( `product_id`, `image_type`, `image_url`, `image_status`) VALUES ('$pt','$m','$mi','$ss'),('$pt','$f','$fi','$ss'),('$pt','$t','$ti','$ss'),('$pt','$s','$si','$ss'),('$pt','$n','$ni','$ss'),('$pt','$u','$ui','$ss'),('$pt','$mic','$mici','$ss')" );
     return $re;
  }
  function insertadmin($n,$u,$p,$i,$s){
   $re=$this->sb->query("INSERT INTO `users`( `name`, `username`, `password`, `image`, `status`) VALUES ('$n','$u','$p','$i','$s')" );
   return $re;
}

function updatemainimage($pi,$id){
 $re=$this->sb->query("update product_list set product_image='https://admin2.blinkme.eu/uploads/productimage/$pi' where product_id=$id" );
   return $re;
}
function selectimagetype($t){
   $re=$this->sb->query("select * from product_images where image_type='$t'" );
   return $re;
}
function selectimagetype2($id,$t){
   $re=$this->sb->query("select * from product_images where product_id=$id and image_type='$t'" );
   return $re;
}
function image($id){
   $re=$this->sb->query("select * from product_images where product_id='$id' ");
   return $re;
}
function updateimage($nid,$mu,$fu,$tu,$su,$nu,$uu,$miu,$oid){
   $re=$this->sb->query("UPDATE product_images SET product_id = $nid, image_url = CASE  WHEN image_type = 'main' THEN '$mu' WHEN image_type = 'front' THEN '$fu' WHEN image_type = 'top' THEN '$tu' WHEN image_type = 'side' THEN '$su'  WHEN image_type = 'nutrition' THEN '$nu'  WHEN image_type = 'usage' THEN '$uu' WHEN image_type = 'misc' THEN '$miu' ELSE image_url  END  WHERE product_id = $oid  AND image_type IN ('main','front', 'top','side','nutrition','usage','misc')");
   return $re; 
} 
function insertdeliveryman($df,$dl,$de,$dt,$dp,$dpa,$di,$ds){
   $re=$this->sb->query("INSERT INTO `deliveryman`( `deliveryman_firstname`, `deliveryman_lastname`, `deliveryman_email`, `deliveryman_type`, `deliveryman_phone`, `deliveryman_password`, `deliveryman_image`, `deliveryman_status`) VALUES ('$df','$dl','$de','$dt','$dp','$dpa','$di','$ds')");
   return $re; 
} 
//insert query for shipping rules
function insertbrach($n,$a,$c,$co,$ad,$e){
   $re=$this->sb->query("INSERT INTO `branch`( `name`, `address`, `city`, `contractno`, `additinalno`, `email_id`) VALUES ('$n','$a','$c','$co','$ad','$e')");
   return $re; 
}
function insertcostomer($n,$m,$e,$a){
   $re=$this->sb->query("INSERT INTO `costumber`( `name`, `mobileno`, `emailid`, `address`) VALUES ('$n','$m','$e','$a')");
   return $re; 
}
function editcostomer($n,$m,$e,$a,$i){
   $re=$this->sb->query("UPDATE `costumber` SET `name`='$n',`mobileno`='$m',`emailid`='$e',`address`='$a' WHERE `id`='$i'");
   return $r;
}
function addproduct($p,$b,$m){
   $re=$this->sb->query("INSERT INTO `product`( `product`, `brand`, `model_no`) VALUES ('$p','$b','$m')");
   return $re; 
}
function addtaxes($i,$c,$r,$s,$b){
   $re=$this->sb->query("INSERT INTO `taxes`( `identifire`, `class_name`, `rate`, `subclass`, `business_activity`) VALUES ('$i','$c','$r','$s','$b')");
   return $re; 
}
function adduser($r,$n,$e,$p){
   $re=$this->sb->query("INSERT INTO `user`( `role`, `name`, `email`, `phone_number`) VALUES ('$r','$n','$e','$p')");
   return $re; 
}
function addclaim($n,$c,$v){
   $re=$this->sb->query("INSERT INTO `claim`( `name`, `claimtype`, `value`) VALUES ('$n','$c','$v')");
   return $re; 
}
function editproducts($p,$b,$m,$i){
   $re=$this->sb->query("UPDATE `product` SET `product`='$p',`brand`='$b',`model_no`='$m' WHERE `id`='$i' ");
   return $re;
}
function addinvoice($jn,$fn,$ln,$mob,$almob,$eml,$adr,$gst,$ptype,$bd,$mn,$mno,$c,$conf,$pass,$si,$si2,$sta,$pro,$cos,$adv,$r,$t,$ddate,$dtime,$cond,$stype,$f){
   $re=$this->sb->query("INSERT INTO `jobsheet`( `jobsheet_number`, `firstname`, `lastname`, `mobile_number`,
    `alternate_mobile`, `email_id`, `address`, `gstin`, `product_type`, `brand`, `model_name`, `modelno`, `color`,
     `configuration`, `password`, `sino`, `sino2`, `status`, `problem`, `cost`, `advance`,`remarks`,`technician`, `delivery_date`,
      `delivery_time`, `condition`, `service_type`,`photo`) VALUES ('$jn','$fn','$ln','$mob',
      '$almob','$eml','$adr','$gst','$ptype','$bd','$mn','$mno',
      '$c','$conf','$pass','$si','$si2','$sta','$pro','$cos',
      '$adv','$r','$t','$ddate','$dtime','$cond','$stype','$f')");
   return $re;
}
function editjobsheet($jn,$f,$l,$mob,$am,$ei,$a,$g,$p,$b,$mn,$mo,$c,$con,$pas,$si,$si2,$pr,$co,$cond,$i){
   $re=$this->sb->query("UPDATE `jobsheet` SET `jobsheet_number`='$jn',`firstname`='$f',
   `lastname`='$l',`mobile_number`='$mob',`alternate_mobile`='$am',`email_id`='$ei',`address`='$a',
   `gstin`='$g',`product_type`='$p',`brand`='$b',`model_name`='$mn',`modelno`='$mo',
   `color`='$c',`configuration`='$con',`password`='$pas',`sino`='$si',`sino2`='$si2',
   `problem`='$pr',`cost`='$co',`condition`='$cond' WHERE `id`='$i' ");
   return $re;
}
function countjobsheet(){
   $r=$this->sb->query('select count(*) from jobsheet');
   return $r;
}
function jobsheetlimit($l1,$l2){
   $r=$this->sb->query("select * from jobsheet limit $l1,$l2");
   return $r;
}
}  
?>