<?php 
require 'includes/dbconfig.php';
if(isset($_SESSION['username']))
{	
}
else 
{
	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>Dashboard - <?php echo $set['d_title'];?></title>
<link rel="shortcut icon"  href="<?php echo $set['logo'];?>">
<!-- General CSS Files -->
<link rel="stylesheet" href="libs/css/bootstrap.min.css">
<link rel="stylesheet" href="libs/css/main.css"/>
<link rel="stylesheet" href="libs/css/style.min.css">
</head>
<body class="layout-4">
<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <div class="navbar-bg"></div>
        <!-- Start app top navbar -->
        <nav class="navbar navbar-expand-lg main-navbar">
            <form class="form-inline mr-auto">
                <ul class="navbar-nav mr-3">
                   
                    
                </ul>
                
            </form>
            <ul class="navbar-nav navbar-right">
                
                <li class="dropdown">

                   

                        
                    </div>
                </li>
            </ul>
        </nav>
 