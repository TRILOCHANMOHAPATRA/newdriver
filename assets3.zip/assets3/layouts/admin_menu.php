

<style>

.scroll {
  width: 260px;
  height: 720px;
    overflow: scroll;
}

</style>
<div class="scroll">
<ul>
<li>
  <li>
    <a href="home.php#" class="submenu-toggle">
    <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
    
  </li>
  <ul>
  <ul>
  <li>
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>branches</span>
    </a>
    <ul class="nav submenu">
      <li><a href="branch.php">branches</a> </li>
      <li><a href="add_branch.php">add branches</a> </li>
   </ul>
  </li>
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>costomer</span>
    </a>
    <ul class="nav submenu">
      <li><a href="costomber.php">costomer</a> </li>
      <li><a href="add_costomber.php">add costomer</a> </li>
   </ul>
  </li>
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>product</span>
    </a>
    <ul class="nav submenu">
      <li><a href="product.php">product</a> </li>
      <li><a href="add_product.php">add product</a> </li>
   </ul>
  </li>
  <li>
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>settings</span>
    </a>
    <ul class="nav submenu">
      <li><a href="profile.php">manage profile</a> </li>
      <li><a href="taxes.php">taxes</a> </li>
      <li><a href="users.php">users</a> </li>
      <li><a href="add_branch.php">Channels</a> </li>
      <li><a href="add_branch.php">distibuters</a> </li>
      <li><a href="claimtype.php">claim types</a> </li>
      <li><a href="add_branch.php">licences</a> </li>
   </ul>
  </li>
  <li>
    <a href="report.php#" class="submenu-toggle">
    <i class="glyphicon glyphicon-home"></i>
      <span>report</span>
    </a>
    
  </li>
  
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>invoice</span>
    </a>
    <ul class="nav submenu">
      <li><a href="list_invoice.php">invoice</a> </li>
      <li><a href="add_invoice.php">add invoice</a> </li>
     
   </ul>
  </li>
  <li>
  <a href="#" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="invoice.php">sales</a> </li>
      <li><a href="add_invoice.php">generate bill</a> </li>
     
   </ul>
  </li>
  <li>
  <a href="https://play.google.com/store/apps/details?id=com.servecircle.servecircle&hl=en&pli=1" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>mobile app</span>
    </a>
   
  </li>
  <li>
  <a href="helpvedio.php" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>Help videos
      </span>
    </a>
   
  </li>
  <li>
  <a href="referral.php" class="submenu-toggle">
    <i class="glyphicon glyphicon-list-alt"></i>
      <span>Refer and earn
      </span>
    </a>
   
  </li>
</li>
  <ul>
 




  
 
 
  






</li>

</ul>
</div>