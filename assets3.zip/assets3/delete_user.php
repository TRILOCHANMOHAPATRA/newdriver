<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$db=new db;
if(isset($_GET['id'])){
    $t='userlogin';
    $c='user_id';
    $i=$_GET['id'];
    $result=$db->Deletedata1($t,$c,$i);
    if($result){
    header('location:customer.php');
}
}
?>