<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
$table='product_images';
$status='image_status';
$product='product_id';
if (isset($_GET['id'])){
    $status_id=$_GET['id'];
    $product_status='0';
   $s=$data->updatestatus($table,$status,$product_status,$product,$status_id);
}
header('location: product_image.php');
?>