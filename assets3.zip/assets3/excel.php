<?php  
  require('includes/dbconfig.php');
  $data=new db;
  if(isset($_GET['id'])){
    $id=$_GET['id'];   
}
  $v=$data-> invoice($id);
$columnHeader = '';  

  
$setData = '';  
  
while ($rec = $v->fetch(PDO::FETCH_ASSOC)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail_Reoprt.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  
  
echo ucwords($columnHeader) . "\n" . $setData . "\n";  
  
?>  