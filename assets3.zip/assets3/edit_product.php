<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
require_once('includes/load.php'); 
?>
<?php
if(isset($_GET['id'])){
    $idd=$_GET['id'];
    $table='product';
    $id='id';
    $r=$data->selectu($table,$id,$idd);
    $row=$r->fetch(PDO::FETCH_ASSOC);
    }
 if(isset($_POST['add_cat'])){
  
  $product=$_POST['product'];
  $brand=$_POST['brand'];
  $model=$_POST['model'];
$iddd=$_POST['aid'];
   if(empty($errors)){
     $re=$data-> editproducts($product,$brand,$model,$iddd);
      if($re){
       header('location:product.php');
      } else {
        header('location:edit_product.php');
      }
   } 
 }
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Add New product</span>
            
         </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="edit_product.php" enctype="multipart/form-data">
          <div class="form-group">
            <label > Product</label>
                <input type="text" class="form-control" name="product" value="<?php echo $row['product'];?>" placeholder="product">
            </div>
            <div class="form-group">
            <label >Brand</label>
                <input type="text" class="form-control" name="brand" value="<?php echo $row['brand'];?>" placeholder="brand">
            </div>
            <div class="form-group">
            <label >Model</label>
                <input type="text" class="form-control" name="model" value="<?php echo $row['model_no'];?>" placeholder="model">
            </div>
            
            <input type="hidden" name="aid" value="<?php echo $row['id']; ?>">
            <button type="submit" name="add_cat" class="btn btn-primary">Add new product</button>
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
  
