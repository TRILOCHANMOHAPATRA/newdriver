<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='product';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
         
          
       </strong>
       <a href="profile.php" class="btn btn-info pull-left">logo</a>
       <a href="accountdetels.php" class="btn btn-info pull-left">Account detels</a>
       <a href="products.php" class="btn btn-info pull-left">product</a>
       <a href="smssender.php" class="btn btn-info pull-left">SMS Sender Id</a>
       <a href="terms.php" class="btn btn-info pull-left">terms and condition</a>
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
        <ul class="form-list-cntr">
                                                    <li>
                                                        <ul class="row">
                                                            <li class="col-lg-3 col-md-4 col-sm-12 form-list-item select2-custom-cntr">
                                                                <select multiple="" class="form-list-input select2-hidden-accessible" id="productType" tabindex="-1" aria-hidden="true">
                                                                    <option></option>
                                                                <option value="145">IT Accessories</option><option value="144">External Hard Drive</option><option value="143">SSD (Solid State Drive)</option><option value="142">Window</option><option value="141">Smoke Detector</option><option value="140">Glue Gun</option><option value="139">Curtain Sensor</option><option value="138">GSM Booster</option><option value="137">Network Video Recorder (NVR)</option><option value="136">Digital Video Recorders (DVR)</option><option value="135">PA System</option><option value="134">Fire Alarm System</option><option value="133">LED TV</option><option value="132">Air Cooler</option><option value="131">Watch</option><option value="130">Photo Copier</option><option value="129">GAS SAFETY DEVICE</option><option value="128">LEISURE EQUIPMENTS</option><option value="127">PLAY EQUIPMENT</option><option value="126">STRENGTH EQUIPMENT</option><option value="125">CARDIO VASCULAR EQUIPMENT</option><option value="124">PUMPSET</option><option value="123">POWER WEEDER</option><option value="122">BRUSH CUTTER</option><option value="121">Battery Sprayer</option><option value="120">POWER SPRAYER</option><option value="119">Switches</option><option value="118">Battery</option><option value="117">NETWORK</option><option value="116">WIFI</option><option value="115">FIREWALL</option><option value="114">THIN CLIENT</option><option value="113">Application Software</option><option value="112">Operating System</option><option value="111">Mouse</option><option value="110">Modem</option><option value="109">ULTRASONIC CLEANER</option><option value="108">LIGHT CURE</option><option value="107">SCALER UNIT</option><option value="106">SCALER HANDIECE</option><option value="105">MICROSURGERY HANDPIECE</option><option value="104">MICROMOTR LAB</option><option value="103">MICROMOTR CLINICAL</option><option value="102">HANDPIECE QUICK COUPLING NON LED</option><option value="101">HANDPIECE QUICK COUPLING LED</option><option value="100">IMPLANT MOTOR(PHYSIODISPENSOR)</option><option value="99">IMPLANT SURGERY HANDPIECE</option><option value="98">ENDOMTOTR CHARGING BASE</option><option value="97">ENDOMOTOR CHARGING ADAPTER</option><option value="96">ENDOMOTOR CONTROL BOX</option><option value="95">ENDOMOTOR</option><option value="94">ENDOACTIVATOR</option><option value="93">ENDODONTIC HANDPIECE</option><option value="92">CONTRA ANGLE HANDPIECE</option><option value="91">DENTAL X RAY MACHINE</option><option value="90">DENTAL CHAIR</option><option value="89">DENTAL COMPRESSOR</option><option value="88">AUTOCLAVE</option><option value="87">AIRMOTOR</option><option value="86">HIGH SPEED HANDPIECE(AIROTOR)</option><option value="85">DENTAL CHAIR</option><option value="84">STRAIGHT HANDPIECE</option><option value="83">AIR PROPHY UNIT</option><option value="82">Power Bank</option><option value="81">DVR (Digital Video Recorder)</option><option value="80">Server</option><option value="79">Keyboard</option><option value="78">POS Machine</option><option value="77">SMPS</option><option value="76">Graphics Card</option><option value="75">Motherboard</option><option value="74">Attendance Machine</option><option value="73">Toner Cartridge</option><option value="72">RAM</option><option value="71">UPS</option><option value="70">RO Water Purifiers</option><option value="69">TV Panel</option><option value="68">Open Cell</option><option value="67">Projector</option><option value="66">Multi-function Printer</option><option value="65">Air Conditioner</option><option value="64">Chimney</option><option value="63">Hob / Stove</option><option value="62">Instant Water Heater</option><option value="61">Matrix Printers</option><option value="60">Ink Printers</option><option value="59">Laser printers</option><option value="58">Scanner</option><option value="57">Network Hubs</option><option value="56">USB Adapters</option><option value="55">Repeaters</option><option value="54">Solar Water Heater</option><option value="53">Solar Panel</option><option value="52">Solar Module</option><option value="51">Binoculars &amp; Telescopes</option><option value="50">Camera Accessories</option><option value="49">Security Cameras (CCTV)</option><option value="48">Camcorders</option><option value="47">Lenses</option><option value="46">Action Cameras</option><option value="45">Compact Cameras</option><option value="44">DSLR Cameras</option><option value="43">Vacuum Cleaners</option><option value="42">MP3 &amp; Media players</option><option value="41">Premium Audio</option><option value="40">Home Theater Systems</option><option value="39">Speakers</option><option value="38">Bluetooth Speakers</option><option value="37">Headphones</option><option value="36">Camera</option><option value="35">Memory Card</option><option value="34">Pen Drive</option><option value="33">Stabilizer</option><option value="32">Adapter</option><option value="31">TV</option><option value="30">LCD</option><option value="29">Portablemediaplayer</option><option value="28">Mixer</option><option value="27">Blender</option><option value="26">Coffeemaker</option><option value="25">Kettles</option><option value="24">Toaster</option><option value="23">Electriccooker</option><option value="22">Wetgrinder</option><option value="21">Washingmachine</option><option value="20">Refrigerator</option><option value="19">Fans</option><option value="18">Ironbox</option><option value="17">Mixergrinder</option><option value="16">Inductionstoves</option><option value="15">Gyser</option><option value="14">Microwave</option><option value="13">Other</option><option value="12">Speaker</option><option value="11">Hard Disk</option><option value="10">Router</option><option value="9">Printer</option><option value="8">Datacard</option><option value="7">Tablet</option><option value="6">Desktop</option><option value="5">CPU</option><option value="4">Charger</option><option value="3">Monitor</option><option value="2">Laptop</option><option value="1">Mobile</option></select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="textbox" aria-autocomplete="list" placeholder="Select Product Type" style="width: 100px;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li>
                                                        <ul class="row">
                                                            <li class="col-lg-12 col-md-12 col-sm-12 form-list-item btn-wrpr">
                                                                <input type="button" id="saveProductSettings" value="Save" class="form-btn">
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
        <tbody>
        
          <tr>
          
          </tr>
        <?php ?>
       </tbody>
     </table>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
<script>
        $(document).ready(function() {
            // Image preview
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#preview-main').attr('src', e.target.result);
                        
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#main").change(function() {
                readURL(this);
            });
        });
    </script>

 
