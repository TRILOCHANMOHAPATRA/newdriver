<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?>


<?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $page='';
  $data=new db;
  $name='jobsheet';
 $jobsheet=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php
if (!isset ($_GET['page']) ) {  
    $page = 1;  
} else {  
    $page = $_GET['page'];  
}  
$from='2023-09-01';
$to='2023-09-28';
if(isset($_GET['detels'])){
  $from=$_GET['start_date'];
  $to=$_GET['end_date'];
  
}
$d=$data->jobsheetdatewise($from,$to);

$result_per_page=10;
$page_first_result=($page-1) * $result_per_page;
$c=$data->countjobsheet();
$cou=$c->fetch(PDO::FETCH_ASSOC);
$count=$cou['count(*)'];
$numofpage=ceil($count/$result_per_page);
$lastpage=($page_first_result + $result_per_page);
$leclimit=$data->jobsheetlimit($page_first_result,$result_per_page);
?> 
     <div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>service</span>
          
       </strong>
       <form action="list_invoice.php" method="get">
       <label for="start_date">Start Date:</label>
<input type="date" name="start_date" >

<label for="end_date">End Date:</label>
<input type="date" name="end_date" >
  <input type="submit" name='detels' value='detels'>
</form>

       <a href="add_invoice.php" class="btn btn-info pull-right">add invoice</a>
       
      </div>
     <div class="panel-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
          <th class="text-center" style="width: 50px;">#</th>
          <th class="text-center" style="width: 50px;">Photos</th>
            <th class="text-center" style="width: 50px;">JobsheetNumber</th>
            <th class="text-center" style="width: 15%;"> product name</th>
            <th class="text-center" style="width: 15%;">mobile number</th>
            <th class="text-center" style="width: 15%;">product name</th>
            <th class="text-center" style="width: 15%;">Costumer Name</th>
            <th class="text-center" style="width: 15%;">Status</th>
            <th class="text-center" style="width: 15%;">Cureent Assignee</th>
           
            <th class="text-center" style="width: 15%;">Action</th>
          </tr>
        </thead>
        <tbody>
        <?php while($row=$d->fetch(PDO::FETCH_ASSOC)){
          $img=$row['photo'];
          ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><img src="photos/<?php echo $img;?>" alt="" title="<?php echo $img; ?>" style="width:200px" /></td>
           <td><?php echo $row['jobsheet_number'];?></td>
           <td><?php echo $row['brand']?></td>
           <td><?php echo $row['mobile_number']?></td>
           <td><?php echo $row['product_type']?></td>
           <td><?php echo $row['firstname'] .$row['lastname'];?></td>
           <td><?php echo $row['status']?></td>
           <td><?php echo $row['firstname'] .$row['lastname'];?></td>
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_invoice.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="glyphicon glyphicon-pencil"></i>
               </a>
                <a href="delete_invoice.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="glyphicon glyphicon-remove"></i>
                </a>
                <a href="view_invoice.php?id=<?php echo $row['id'];?>" class="btn btn-xs btn-green" data-toggle="tooltip" title="view">
                <i class="glyphicon glyphicon-play"></i>
                </a>
                <a href="print.php?id=<?php echo $row['id']; ?>"  class="btn btn-info pull-right">print</a>
         <a href="excel.php?id=<?php echo $row['id']; ?>"  class="btn btn-info pull-right">Excel</a>
         <a href="print_invoice.php?id=<?php echo $row['id']; ?>" class="btn btn-info pull-right">print invoise</a>
                </div>
           </td>
          
          </tr>
         
          <?php
        
        }?>
        
       </tbody>
      
     </table>
     
    </div>
  </div>
 
 
</div>
<?php include_once('layouts/footer.php'); ?>
<?php 
  if($page>1)
  {
      echo "<a href='list_invoice.php?page=".($page-1)."' class='btn btn-danger'><</a>";
  }
  for($i=1;$i<$numofpage;$i++)
  {
      echo "<a href='list_invoice.php?page=".$i."' class='btn btn-primary'>$i</a>";
  }
  if($i>$page)
  {
      echo "<a href='list_invoice.php?page=".($page+1)."' class='btn btn-danger'>></a>";
  }
             ?>
              </table><div class="dataTables_info" id="example_info" role="status" aria-live="polite">Showing <?php echo $page_first_result;?> to <?php echo $lastpage;?> of <?php echo $count;?> entries</div><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"></div></div>
