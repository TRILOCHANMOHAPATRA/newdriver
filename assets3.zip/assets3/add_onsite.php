<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
require('includes/dbconfig.php');
$data=new db;
$table='product_type';
$b='brand';
$m='model';
$t='techician';
$product_type=$data->select($table);
$br=$data->select($b);
$mo=$data->select($m);
$tc=$data->select($t);
require_once('includes/load.php'); 
?>
<?php
 if(isset($_POST['submit'])){
  $jnumber=$_POST['jnumber'];
 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
 $mobile=$_POST['mobile'];
 $amobile=$_POST['amobile'];
 $email=$_POST['email'];
 $address=$_POST['address'];
 
 $gstin=$_POST['gstin'];
 $type=$_POST['type'];
 
 $brand=$_POST['brand'];
 
 $modelname=$_POST['modelname'];
 
 $modelnumber=$_POST['modelnumber'];
 $color=$_POST['color'];
 $configuration=$_POST['configuration'];
 $password=$_POST['password'];
 $imeino=$_POST['imeino'];
 $imeino2=$_POST['imeino2'];
 $status=$_POST['status'];
 $problem=$_POST['problem'];
  $condition=$_POST['condition'];
 $estimate=$_POST['estimatedCost'];
 $advance=$_POST['advance'];
 $remark=$_POST['remark'];
 $technician=$_POST['technician'];
 $edate=$_POST['edate'];
 $etime=$_POST['etime'];
$id=3;
  
$re=$data->addinvoice($jnumber,$firstname,$lastname,$mobile,$amobile,$email,$address,$gstin,$type,$brand,$modelname,$modelnumber,
$color,$configuration,$password,$imeino,$imeino2,$status,$problem,$estimate,$advance,$remark,$technician,$edate,$etime,$condition,$id);
      if($re){
       header('location:list_invoice.php');
      } else {
        header('location:add_invoice.php');
      }
   } 
 
?>
<?php include_once('layouts/header.php'); ?>
   <div class="row">
    <div class="col-md-10">
      <div class="panel panel-default">
        <div class="panel-heading">
        <strong>
        <span class="glyphicon glyphicon-th"></span>
            <span>Add New onsite </span>
           </strong>
       
        </div>
        <div class="panel-body">
          <form method="post" action="add_invoice.php" >
          <ul class="form-list-cntr">
                                                        <li class="form-list-item">
                                                            <div>
                                                                <label class="d-block form-list-label">Service Type</label>
                                                                <div>
                                                                <label class="d-block form-list-label">invoice<span class="mandatory-field">*</span></label>  
                                                                <a href="add_invoice.php">
  <input type="radio" style="pointer-events:none;">
</a>
<label class="d-block form-list-label">pickup<span class="mandatory-field">*</span></label>
<a href="add_pickup.php">
  <input type="radio" style="pointer-events:none;">
</a>
<label class="d-block form-list-label">onsite<span class="mandatory-field">*</span></label>
<a href="add_onsite.php">
  <input type="radio" style="pointer-events:none;">
</a>
                                                                </div>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">jobsheet number<span class="mandatory-field"></span></label>
                                                                    <input type="tel" name="jnumber" class="form-list-input" maxlength="10" placeholder="jobsheet number">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Customer Information</div>
                                                            <ul class="row ">
                                                            <li class="col-lg-3 col-md-4 col-sm-12 ">
                                                                    <label class="d-block form-list-label">First Name<span class="mandatory-field">*</span></label>
                                                                   
                                                                    <input type="text" name="firstname" class="form-list-input float-left customer-first-name" maxlength="50" placeholder="firstname">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Last Name</label>
                                                                    <input type="text" name="lastname" class="form-list-input" maxlength="50" placeholder="lastname">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">Mobile Number<span class="mandatory-field">*</span></label>
                                                                    <input type="tel" name="mobile" class="form-list-input" maxlength="10" placeholder="mobile number">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 ">
                                                                    <label class="d-block form-list-label">Alternate Mobile Number</label>
                                                                    <input type="tel" name="amobile" class="form-list-input" maxlength="20" placeholder="Alternate Mobile Number">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 ">
                                                                    <label class="d-block form-list-label">Email </label>
                                                                    <input placeholder="Enter valname Email name's only" type="email" name="email" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">address</label>
                                                                    <input  type="text" name="address" class="form-list-input" maxlength="50" placeholder="address">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">gstin</label>
                                                                    <input  type="text" name="gstin" class="form-list-input" maxlength="50" placeholder="gstin">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
</li>
                                                                
																<li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label >Brand</label>
            <select  class="form-control" name="brand" id="brand">
            <option>Select brand</option>
            <?php while($row=$br->fetch(PDO::FETCH_ASSOC)){ ?>
            <option value="<?php echo $row['brand_name'];?>"><?php echo $row['brand_name']; ?></option>
            <?php } ?>
           
            </select>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                        <li>
                                                            <div class="create-job-sheet-hdg">Product Information</div>
                                                            <ul class="row">
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item select2-custom-cntr">
                                                                <label >product Types</label>
            <select  class="form-control" name="type" id="status">
            <option>Select product type</option>
            <?php while($row=$product_type->fetch(PDO::FETCH_ASSOC)){?>
            <option value="<?php echo $row['product_name'] ?>"><?php echo $row['product_name']; ?></option>
            <?php }?>
            </select>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label >model</label>
            <select  class="form-control" name="modelname" id="status">
            <option>Select modelname</option>
            <?php while($row=$mo->fetch(PDO::FETCH_ASSOC)){ ?>
            <option value="<?php echo $row['model_name'];?>"><?php echo $row['model_name']; ?></option>
           <?php } ?>
            </select>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label class="d-block form-list-label">modelnumber</label>
                                                                    <input type="text" name="modelnumber" class="form-list-input" maxlength="50">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">color</label>
                                                                    <input type="text" name="color" class="form-list-input" maxlength="50" placeholder="color">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">configuration</label>
                                                                    <input type="text" name="configuration" class="form-list-input" maxlength="50" placeholder="configuration">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">password</label>
                                                                    <input type="password" name="password" placeholder="Password" class="form-list-input" maxlength="50">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">imeino <span class="pattern-icon" name="btnPatternLock"><i class="fa fa-circle"></i></span></label>
                                                                    <input type="text" name="imeino" class="form-list-input" placeholder="Password" maxlength="20">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label"><span name="si1NoLabel">imeino2</span> 1</label>
                                                                    <input type="text" name="imeino2" class="form-list-input" maxlength="25">
                                                                </li>
                                                                
                                                                
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label"><span name="si1NoLabel">status</span> </label><br>
                                                                    <label for="option1">Warranty
</label>
<input type="radio" id="option1" name="status" value="option1">

<label for="option2">Non Warranty
</label>
<input type="radio" id="option2" name="status" value="option2"><br>

<label for="option3">AMC</label>
<input type="radio" id="option3" name="status" value="option3">
<label for="option3">Return</label>
<input type="radio" id="option3" name="status" value="option3">
                                                                </li>
                                                                   
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" name="warrantyRefNo">
                                                                    <label class="d-block form-list-label">problem</label>
                                                                    <input type="text" name="problem" class="form-list-input" maxlength="50" placeholder="problem">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                    <label class="d-block form-list-label">condition</label>
                                                                    <input type="text" name="condition" class="form-list-input" maxlength="50" placeholder="condition">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Estimated Cost (Rs.)</label>
                                                                    <input type="text" name="estimatedCost" class="form-list-input" maxlength="20" placeholder="Estimated Cost (Rs.)">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Advance  (Rs.)</label>
                                                                    <input type="text" name="advance" class="form-list-input" maxlength="20" placeholder="Advance Paname (Rs.)">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Remarks</label>
                                                                    <input type="text" name="remark" class="form-list-input" maxlength="20" placeholder="Remarks">
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item">
                                                                <label >Technician</label>
            <select  class="form-control" name="technician" id="technician">
            <option>Select technician</option>
            <?php while($row=$tc->fetch(PDO::FETCH_ASSOC)){ ?>
            <option value="<?php echo $row['techician_name'];?>"><?php echo $row['techician_name']; ?></option>
            <?php } ?>
           
            </select>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Expected Delivery Date</label>
                                                                    <input type="date" name="edate" class="form-list-input hasDatepicker" maxlength="40"  placeholder="Expected Delivery Date">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                <li class="col-lg-3 col-md-4 col-sm-12 form-list-item" >
                                                                    <label class="d-block form-list-label">Expected Delivery time</label>
                                                                    <input type="time" name="etime" class="form-list-input hasDatepicker" maxlength="40"  placeholder="Expected Delivery time">
                                                                    <span class="form-list-input-error"></span>
                                                                </li>
                                                                
                                                                <label for="option1">Don't send SMS and E-mail alerts to the customer</label>
<input type="checkbox" id="option1" name="options[]" value="option1">
                                                                
                                                                <button type="submit" name="submit" class="btn btn-primary">Add invoice</button>
            </li>
                                                    </ul>
  
        </form>
        </div>
      </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>

