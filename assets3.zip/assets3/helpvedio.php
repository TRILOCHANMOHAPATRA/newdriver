<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: index.php");
    exit;
}
?><?php
include_once('layouts/header.php'); 
  require('includes/dbconfig.php');
  $data=new db;
  $name='costumber';
 $userlogin=$data->select($name);
  require_once('includes/load.php'); 
?>
<?php  ?> 
<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Getting started with services and repairs management

</h5>
        <a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Creating your first job sheet (service request).

</h5>
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">Hindi</a> 
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Completing the service and closing the job card

</h5>
       
        <a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">Hindi</a> 
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a> 
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Billing a closed service and delivering the product

</h5>
       
        <a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">Hindi</a> 
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Getting started with sales invoicing

</h5>
        
       
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Adding users, assigning branches and roles to them

</h5>
        
       
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Getting started with Inventory</h5>
        
         
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Adding tax classes and generating tax invoices

</h5>
       
       
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Creating service account to each of your clients

</h5>
        
        
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
     
      <div class="card-body">
        <h5 class="card-title">Distribution to your branches or franchisee using ServeCircle

</h5>
        
        
<a href="https://www.youtube.com/watch?v=coMwC_OcW0I" class="btn btn-info ">English</a>
    </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

 
